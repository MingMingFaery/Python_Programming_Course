#define ILOUSESTL
using namespace std;
#ifndef MDMKP_TYPEDEF_H
#define MDMKP_TYPEDEF_H
#include <string>
#include <cstring>
#include <fstream>
#include <iostream>
#include <vector>
#include <list>
#include <valarray>
#include <stdio.h>
#include <ctime>
#include <map>
#include <algorithm>
#include <ilcplex/ilocplex.h>
//using namespace std;

#define MAXVALUE 99999999
#define EMPTY (-1)

// 0301
class Tabu_new;

class Output {
public:
    Output(float if_print, string now = "");
    void printOutput();
    string output(const string& file) const;
    void output_sol(const string& file) const;
    static string format(const string& str, int length = 8);
    static string formato(const string& str, int length = 25);
    static string formati(const int& a, int length = 8);
    static string formatf(const float& b, int length = 8);
    void getSubInfo(const Output& subOutput);
    void out_parameters(map<string, float> par);
    void out_parameters(map<string, double> par);

    clock_t beginTime{};
    double totalTime{};
    double findBestTime{};
    int iter{};
    int stagnant{};
    int emptyNum{};
    double swapTime{};
    double flipTime{};
    string output_info{};
    string iter_info{};
    string sol_temp{};
    string score_info{};
    double updateTime{};
    int tabuNum{};
    int iter_total{};
    map <string, double> times{};
};

class Input {
public:
    Input(int seed, string time);
    map <string, float> parameters;
    bool fea{}; // ??
    int seed{};
    double k{};
    int nChange_times{};
    int allIter{};
    string now{};
};

class Move_new {
public:
    Move_new();
    Move_new(Move_new before, int ins_profit, int** ins_resource, bool sol_select, int item);
    Move_new(int* select, Move_new before, int ins_profit, int** ins_resource, bool sol_select, int item);
    void update_oper(int ins_attrNum, int ins_profit, int** ins_resource, bool sol_select, int item);
    void update_oper_0613(int* select, int number, int ins_profit, int** ins_resource, bool sol_select, int item);
    int itemNum = 0;
    int attrNum = 0;
    int items[10] = { 0 };
    int status[10] = { 0 };
    int attr_delta[180] = { 0 };
    int obj = EMPTY;
    int delta = 0;
    double eva = -MAXVALUE;
    double feasible = 0;
    int feaNum = 0;
    int omp = -1;
};

class Instance {
public:
    explicit Instance(string file);
    Instance();
    void printInformation(Output& output) const;
    ~Instance();
    string insName{};
    int itemNum{};
    int upperNum{};
    int floorNum{};
    int attrNum{};
    int fixedIter{};
    int max_resource{};
    int* profit{};
    int* threshold{};
    int* attrType{};
    int** resource{};
    int* fixedFreq{};
};

class SubInstance : public Instance {
public:
    SubInstance(Instance& ins, const int* isFixed);
    SubInstance(int itemNum, int upperNum, int floorNum, int totalItemNum);
    void beCovered(const SubInstance& ins, int total);
    ~SubInstance();

    int mainItemNum{};
    int leaveObj{};
    int* fixed{};
};

class Solution {
public:
    explicit Solution(const Instance& ins, float gammaBase, float gammaDelta);
    ~Solution();
    void initialize_random(const Instance& ins);
    void initialize_matrix(const Instance& ins, float* matrix);
    void evaluate(const Instance& ins);
    void printInformation(Output& output) const;
    void printSol(const Instance& ins) const;
    void execute_new(const Instance& ins, Move_new opert);
    void destroy(const Instance& ins, float rate);
    void beCovered(const Solution& sol);
    void output(const string& file, const Instance& ins) const;
    void save_solution(const Instance& ins, Output& output) const;
    void check(const Instance& ins, Output& output) const;
    void getTabuScore(const long long* weight1, const long long* weight2, const long long* weight3) const;
    void restoreSol(const Solution& subSol, const Instance& mainIns, const SubInstance& subIns);


    int itemNum{};
    int attrNum{};
    int k{};
    int obj{};
    double feasible{};
    double gamma = 1.0;
    double eva{};
    int feaNum{};
    bool* select{};
    int* attrFeasible{};
    int* occupy{};
    double* attrGamma{};
    long long* tabuLoc{};
    float gammaBase{};
    float gammaDelta{};
};

class ILP {
public:
    ILP(const Instance& ins);
    void printILP();
    void calculate(const Solution& sol);
    void restoreILP(ILP& subsolver, const SubInstance& subIns);
    ~ILP();

    int size{};
    float objValue{};
    float k{};
    int intNum{};
    float maxReduce{};
    float* scoreR{};
    float* reduceCost{};
    float* x{};
    float* scoreX{};

};

class Tabu_Sol {//0619
public:
    explicit Tabu_Sol(int itemNum, float expr = 0);
    ~Tabu_Sol();
    void tabuSol(const Solution& sol) const;
    [[nodiscard]] bool judgeTabu_new(const Solution& sol, const Move_new& oper);

    int tabuNum{};
    long int length{};
    double gamma1{};
    double gamma2{};
    double gamma3{};
    bool* hash1{};
    bool* hash2{};
    bool* hash3{};
    int* bucket{};
    long long* weight1{};
    long long* weight2{};
    long long* weight3{};

};

class Frequency {
public:
    explicit Frequency(const Instance& ins);
    void initial(const ILP& solver);
    void initial();
    void updateFreq(Solution& sol);
    void updateFixed();
    void restoreFreq(Frequency& subFreq, const SubInstance& subIns);
    void flipFixed(const Solution& sol) const;
    void getFreqScore();
    void updateFixed(const bool* select, float* scoreX, int* fixedFreq, int iter, float fixRate, float scoreWeight = 0.5);
    void updateFixed(const bool* select, float* scoreX, int* fixedFreq, float* reduceCost, int iter, float fixRate, float scoreWeight = 0.5, int exprType = 4);
    void destruction(float rate, const bool* select);
    ~Frequency();

    int iter{};
    int total{};
    int size{};
    int fixNum{};
    double threshold{};
    double k{};
    bool lastSolFea{};
    int* freq{};
    int* isFixed{};
    float* score{};
    double rate{};
    float fixRate{};
};

class Qlearning_ex {
public:
    Qlearning_ex(string par, string cand, float a, float r);
    void selectOper();
    float update(int oldObj, int oldinfea, int newObj, int newinfea);
    void getResult();
    string output();
    ~Qlearning_ex();

    int size{};
    int state{};
    int oper{};
    string name{};
    float alpha{};
    float gamma{};
    float res{};
    float* candidate{};
    float** matrix{};
};

class Func {
public:
    static void printVector(int* vector, int size);
    static void updateOpers(vector<Move_new>& operators, Move_new oper);
    static void read(const string& path, const string& insNames, vector <string>& files);
    // static float printTime(int type=0,int size=0,int repeat=0,int total=0,string info="");
    static map<string, int> getBestKown();
};

class Run {
public:
    static int run_single(string path, string out_path, string now, int expr = 0, int i = 0);
    static void run_ins_set(int re, string path, string ins_set, int expr = 0);
    static void set_single_input_parameters(map<string, float>& parameters, string ins, int itemNum);
};

class Output_fun {
public:
    static string printOper(const Move_new oper);
    static void printOpers(const vector<Move_new>& operators);
    static string get_iter_info(float judge, int iter, int stagnant, int sub_iter, float sub_time, float total_time, int item_num, int sub_obj, int obj, int feaNum, int k, int best_obj);
};

void SEARCH_new(Instance& ins, Solution& sol, Input& input);
void SEARCH_base(Instance& ins, Solution& sol, Input& input);
void SEARCH_Qlearning(Instance& ins, Solution& sol, Input& input);
string SEARCH_Qlearning_ex(Instance& ins, Solution& sol, Input& input);

void firstSearch_new(const Instance& ins, Solution& sol, Frequency& fModel, Input& input, Output& output);

#endif //MDMKP_TYPEDEF_H
