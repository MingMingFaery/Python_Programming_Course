g++ -o main_exe ./base/main.cpp

g++ -I"D:\CPLEX\CPLEX_Studio\cplex\include" -I"D:\CPLEX\CPLEX_Studio\concert\include" ./base/main.cpp -o main_exe -L "D:\CPLEX\CPLEX_Studio\cplex\lib\x64_windows_msvc14\stat_mda" -lilocplex -L "D:\CPLEX\CPLEX_Studio\concert\lib\x64_windows_msvc14\stat_mda" -lconcert -L "D:\CPLEX\CPLEX_Studio\cplex\lib\x64_windows_msvc14\stat_mda" -lcplex -lm