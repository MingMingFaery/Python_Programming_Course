﻿#include "TypeDef.h"
#define IFPRINT 0
#define IFOUT_ITER_INFO 1
#define TIME_LIMIT 500

string getTime0() {
    time_t timep;
    time(&timep);
    char tmp[64];
    struct tm nowTime;
    //localtime_s(&nowTime, &timep);   // on Windows
    localtime_r(&timep, &nowTime); // on Linuxs
    strftime(tmp, sizeof(tmp), "%Y-%m-%d-%H:%M:%S", &nowTime);
    string locTime(tmp);
    return locTime;
}

int main00(int argc, char* argv[]) {
    string input_file = R"(../newins/9-1000-60-60-1.0-0.25-M.txt )";//250-5-5-0-1.txt
    string out_path = "../out/";
    string now = getTime0();
    Run::run_single(input_file, out_path, now);
    return 0;
}

int main(int argc, char* argv[]) {
    const char* input = argv[argc - 2];
    int expr = atoi(argv[argc - 1]);
    int repeat = 9; // 36
    string input_file(input);
    string out_path = "./out/";
    for (int i = 1;i <= repeat;++i) {
        try {
            string now = getTime0();
            Run::run_single(input_file, out_path, now, expr, i);
        }
        catch (const std::exception&) {
            cout << input << " has mistake!" << i << endl;
        }
    }
    return 0;
}

int main0(int argc, char* argv[]) {
    string select = R"(../select.txt )";
    string ins = R"(../All/)";
    int expr = atoi(argv[argc - 1]);
    int re = atoi(argv[argc - 2]);
    Run::run_ins_set(re, ins, select, expr);
    return 0;
}

void Output::printOutput() {
    output_info += Output::formato("The totalTime") + to_string(totalTime) + "\n";
    output_info += Output::formato("The FlipTime") + to_string(flipTime / totalTime) + "\n";
    output_info += Output::formato("The SwapTime") + to_string(swapTime / totalTime) + "\n";
    output_info += Output::formato("The UpdateTime") + to_string(updateTime / totalTime) + "\n";
    output_info += Output::formato("The findBestTime") + to_string(findBestTime) + "\n";
    output_info += Output::formato("The iter") + to_string(iter) + "\n";
    output_info += Output::formato("The stagnant") + to_string(stagnant) + "\n";
    output_info += Output::formato("The ALL_iter") + to_string(iter_total) + "\n";
    output_info += Output::formato("The tabuNum") + to_string(tabuNum) + "\n";
}

string Output::output(const string& file) const {
    string info = "";
    info += output_info + "\n";
    if (IFOUT_ITER_INFO == 1) {
        info += iter_info + "\n";
    }
    info += sol_temp + "\n";
    info += "-------------------------\n";
    return info;
}

void Output::output_sol(const string& file) const {
    ofstream dataFile;
    dataFile.open(file, ofstream::app);
    if (!dataFile.is_open()) {
        fprintf(stderr, "Can not open file %s\n", file.c_str());
        exit(10);
    }
    //    dataFile << "vertexNumber "<<"edgeNumber "<<"objectValue "<<"injection(candidateGraphVertex : hostGraphIndex)"<<endl;
    dataFile << "Sol :          : " << endl;
    dataFile << sol_temp << endl;
    dataFile.close();
}

Output::Output(float if_print, string now) {
    iter_total = 0;
    tabuNum = 0;
    output_info = Output::formato("The now_time") + now + "\n";
    beginTime = clock();
    iter_info += Output::format("iter", 4);
    iter_info += Output::format("stag", 4);
    iter_info += Output::format("iterNum");
    iter_info += Output::format("time");
    iter_info += Output::format("totalT");
    iter_info += Output::format("itemN", 5);
    iter_info += Output::format("subSolObj", 10);
    iter_info += Output::format("solObj");
    iter_info += Output::format("feaNum");
    iter_info += Output::format("k", 5);
    iter_info += Output::format("bestObj");
    iter_info += "\n";
    if (if_print > 0) {
        cout << iter_info;
    }
}

string Output::formato(const string& str, int length) {
    string s;
    if (str.size() < length) {
        s += str;
        for (int index = 0; index < length - str.size(); ++index) {
            s += " ";
        }
    }
    else {
        s += str;
    }
    s += ": ";
    return s;
}

string Output::format(const string& str, int length) {
    string s;
    if (str.size() < length) {
        for (int index = 0; index < length - str.size(); ++index) {
            s += " ";
        }
        s += str;
    }
    else {
        s += str;
    }
    s += "|";
    return s;
}

string Output::formati(const int& a, int length) {
    string str = to_string(a);
    return format(str, length);
}

string Output::formatf(const float& b, int length) {
    string str;
    string str1 = to_string(b);
    unsigned int loc = str1.find_first_of(to_string(1.1)[1]) + 3;
    for (unsigned int l = 0; l < loc; l++) {
        str += str1[l];
    }
    return format(str, length);
}

void Output::getSubInfo(const Output& subOutput) {
    swapTime += subOutput.swapTime;
    flipTime += subOutput.flipTime;
    updateTime += subOutput.updateTime;
    tabuNum += subOutput.tabuNum;
    iter_total += subOutput.iter;
    for (auto& t : subOutput.times) {
        times[t.first] += t.second;
    }
}

void Output::out_parameters(map<string, float> par) {
    for (auto& t : par) {
        output_info += Output::formato("Thi " + t.first) + to_string(t.second) + " \n";
    }
}
void Output::out_parameters(map<string, double> par) {
    for (auto& t : par) {
        output_info += Output::formato("Tho " + t.first) + to_string(t.second) + " \n";
    }
}

string Output_fun::printOper(const Move_new oper) {
    string temp = "";
    for (int item = 0;item < oper.itemNum;++item) {
        if (oper.status[item] == 1) {
            temp += "+" + to_string(oper.items[item]);
        }
        else {
            temp += "-" + to_string(oper.items[item]);
        }
    }
    string tempStr = Output::format(temp, 13) + Output::formati(oper.delta) + Output::formati(oper.obj) +
        Output::formatf(oper.feasible, 10) + Output::formatf(oper.eva, 10) +
        Output::formati(oper.feaNum) + Output::formati(oper.omp) + "\n";
    return tempStr;
}

void Output_fun::printOpers(const vector<Move_new>& operators) {
    int iter = 0;
    for (Move_new a : operators) {
        string tempStr = Output::formati(iter, 4) + Output_fun::printOper(a);
        cout << tempStr;
    }
}

string Output_fun::get_iter_info(\
    float judge, int iter, int stagnant, int sub_iter, \
    float sub_time, float total_time, int item_num, \
    int sub_obj, int obj, int feaNum, int k, int best_obj) {
    string tempStr = Output::formati(iter, 4) + Output::formati(stagnant, 4) + Output::formati(sub_iter) +
        Output::formatf(sub_time) + Output::formatf(total_time) +
        Output::formati(item_num, 5) + Output::formati(sub_obj, 10) +
        Output::formati(obj) + Output::formati(feaNum) + Output::formati(k, 5) + Output::formati(best_obj) + "\n";
    if (judge > 0) {
        cout << tempStr;
    }
    return tempStr;
}

Input::Input(int seed, string time) {
    this->seed = seed;
    srand(seed);
    parameters["seed"] = seed;
    now = time;
}

Move_new::Move_new() {
    memset(items, -1, sizeof(int) * 10);
    memset(status, 0, sizeof(int) * 10);
    memset(attr_delta, 0, sizeof(int) * 180);

}

Move_new::Move_new(Move_new before, int ins_profit, int** ins_resource, bool sol_select, int item) {
    memcpy(items, before.items, sizeof(int) * 10);
    memcpy(status, before.status, sizeof(int) * 10);
    memcpy(attr_delta, before.attr_delta, sizeof(int) * 180);
    attrNum = before.attrNum;
    itemNum = before.itemNum + 1;
    items[itemNum - 1] = item;
    status[itemNum - 1] = 1 - 2 * sol_select;
    delta = before.delta + status[itemNum - 1] * ins_profit;
    for (int attr = 0;attr < attrNum;++attr) {
        attr_delta[attr] = before.attr_delta[attr] + status[itemNum - 1] * ins_resource[attr][item];
    }
}

Move_new::Move_new(int* select, Move_new before, int ins_profit, int** ins_resource, bool sol_select, int item) {
    memcpy(items, before.items, sizeof(int) * 10);
    memcpy(status, before.status, sizeof(int) * 10);
    memcpy(attr_delta, before.attr_delta, sizeof(int) * 180);
    attrNum = before.attrNum;
    itemNum = before.itemNum + 1;
    items[itemNum - 1] = item;
    status[itemNum - 1] = 1 - 2 * sol_select;
    delta = before.delta + status[itemNum - 1] * ins_profit;
    for (int attr = 0;attr < attrNum;++attr) {
        attr_delta[attr] = before.attr_delta[attr] + status[itemNum - 1] * ins_resource[select[attr]][item];
    }
}

void Move_new::update_oper(int ins_attrNum, int ins_profit, int** ins_resource, bool sol_select, int item) {
    attrNum = ins_attrNum;
    itemNum += 1;
    items[itemNum - 1] = item;
    status[itemNum - 1] = 1 - 2 * sol_select;
    delta += status[itemNum - 1] * ins_profit;
    for (int attr = 0;attr < ins_attrNum;++attr) {
        attr_delta[attr] += status[itemNum - 1] * ins_resource[attr][item];
    }
}

void Move_new::update_oper_0613(int* select, int number, int ins_profit, int** ins_resource, bool sol_select, int item) {
    attrNum = number;
    itemNum += 1;
    items[itemNum - 1] = item;
    status[itemNum - 1] = 1 - 2 * sol_select;
    delta += status[itemNum - 1] * ins_profit;
    for (int attr = 0;attr < attrNum;++attr) {
        attr_delta[attr] += status[itemNum - 1] * ins_resource[select[attr]][item];
    }
}

long long get_bucket_loc(long long loc1, long long loc2, long long loc3, long long length) {
    long long a1 = loc1 ^ (loc2 * 2) ^ (loc3 * 4);
    long long loc = a1 % length;
    return loc;
}

Tabu_Sol::Tabu_Sol(int itemNum, float expr) {
    length = 2000003;
    gamma1 = 2.4;
    gamma2 = 2.6;
    gamma3 = 2.3;
    hash1 = new bool [length] {false};
    hash2 = new bool [length] {false};
    hash3 = new bool [length] {false};
    bucket = new int [length] {0};
    weight1 = new long long [itemNum] {0};
    weight2 = new long long [itemNum] {0};
    weight3 = new long long [itemNum] {0};
    for (int item = 0; item < itemNum; ++item) {
        weight1[item] = pow(item + 1, gamma1);
        weight2[item] = pow(item + 100, gamma2);
        weight3[item] = pow(itemNum - item + 1, gamma3);
    }
}

Tabu_Sol::~Tabu_Sol() {
    delete[] hash1;
    delete[] hash2;
    delete[] hash3;
    delete[] weight1;
    delete[] weight2;
    delete[] weight3;
    delete[] bucket;
}

void Tabu_Sol::tabuSol(const Solution& sol) const {
    long long loc1 = sol.tabuLoc[0] % length;
    long long loc2 = sol.tabuLoc[1] % length;
    long long loc3 = sol.tabuLoc[2] % length;
    long long loc = get_bucket_loc(loc1, loc2, loc3, length);
    hash1[loc1] = true;
    hash2[loc2] = true;
    hash3[loc3] = true;
    bucket[loc] += 1;
}

bool Tabu_Sol::judgeTabu_new(const Solution& sol, const Move_new& oper) {
    long long loc1 = sol.tabuLoc[0];
    long long loc2 = sol.tabuLoc[1];
    long long loc3 = sol.tabuLoc[2];
    for (int item = 0;item < oper.itemNum;++item) {
        loc1 += oper.status[item] * weight1[oper.items[item]];
        loc2 += oper.status[item] * weight2[oper.items[item]];
        loc3 += oper.status[item] * weight3[oper.items[item]];
    }
    loc1 = loc1 % length;
    loc2 = loc2 % length;
    loc3 = loc3 % length;
    long long loc = get_bucket_loc(loc1, loc2, loc3, length);
    if (hash1[loc1] && hash2[loc2] && hash3[loc3] && bucket[loc] > 0) {
        tabuNum++;
        return true;
    }
    else {
        return false;
    }
}

Instance::Instance(string input_file) {
    unsigned int loc = input_file.find_last_of('/') + 1;
    while (input_file[loc] != '\0' && input_file[loc] != ' ') {
        insName.push_back(input_file[loc]);
        loc++;
    }
    const char* file = input_file.c_str();
    ifstream inputFile(file);
    if (!inputFile) {
        fprintf(stderr, "Can not open file %s\n", file);
        exit(10);
    }
    inputFile >> itemNum >> upperNum >> floorNum;
    attrNum = upperNum + floorNum;
    profit = new int[itemNum];
    threshold = new int[attrNum];
    attrType = new int[attrNum];
    resource = new int* [attrNum];
    fixedFreq = new int [itemNum] {0};
    for (int attr = 0; attr < attrNum; ++attr) {
        resource[attr] = new int[itemNum];
        if (attr < upperNum) {
            attrType[attr] = 1;
        }
        else {
            attrType[attr] = -1;
        }
    }
    for (int item = 0; item < itemNum; ++item) {
        inputFile >> profit[item];
    }
    for (int upper = 0; upper < upperNum; ++upper) {
        for (int item = 0; item < itemNum; ++item) {
            inputFile >> resource[upper][item];
        }
    }
    for (int upper = 0; upper < upperNum; ++upper) {
        inputFile >> threshold[upper];
    }
    for (int floor = 0; floor < floorNum; ++floor) {
        for (int item = 0; item < itemNum; ++item) {
            inputFile >> resource[upperNum + floor][item];
        }
    }
    for (int floor = 0; floor < upperNum; ++floor) {
        inputFile >> threshold[upperNum + floor];
    }
    max_resource = 0;
    for (int item = 0;item < itemNum;item++) {
        for (int attr = 0;attr < attrNum;attr++) {
            if (resource[attr][item] > max_resource) {
                max_resource = resource[attr][item];
            }
        }
    }

}

Instance::~Instance() {
    for (int index = 0; index < attrNum; ++index) {
        delete[] resource[index];
    }
    delete[] profit;
    delete[] threshold;
    delete[] attrType;
    delete[] resource;
}

void Instance::printInformation(Output& output) const {
    output.output_info += Output::formato("The Ins_Name") + insName + "\n";
    output.output_info += Output::formato("The Item_Num") + to_string(itemNum) + "\n";
    output.output_info += Output::formato("The Upper_Limit_Num") + to_string(upperNum) + "\n";
    output.output_info += Output::formato("The Floor_Limit_Num") + to_string(floorNum) + "\n";
    output.output_info += Output::formato("The Attribute_Num") + to_string(attrNum) + "\n";
}

Instance::Instance() = default;

SubInstance::SubInstance(Instance& ins, const int* isFixed) {
    int fixNum = 0;
    ins.fixedIter++;
    for (int item = 0; item < ins.itemNum; ++item) {
        if (isFixed[item] != 0) {
            fixNum++;
            ins.fixedFreq[item] += 1;
        }
    }
    mainItemNum = ins.itemNum;
    insName = ins.insName + "_cut_" + to_string(fixNum);
    itemNum = ins.itemNum - fixNum;
    upperNum = ins.upperNum;
    floorNum = ins.floorNum;
    attrNum = ins.attrNum;
    max_resource = ins.max_resource;
    profit = new int[itemNum];
    threshold = new int[attrNum];
    attrType = new int[attrNum];
    resource = new int* [attrNum];
    fixed = new int[ins.itemNum];
    leaveObj = 0;
    int index = 0;
    for (int item = 0; item < ins.itemNum; ++item) {
        fixed[item] = isFixed[item];
        if (isFixed[item] == 0) {
            profit[index] = ins.profit[item];
            index++;
        }
        else if (isFixed[item] == 1) {
            leaveObj = leaveObj + ins.profit[item];
        }
    }
    for (int attr = 0; attr < attrNum; ++attr) {
        attrType[attr] = ins.attrType[attr];
        threshold[attr] = ins.threshold[attr];
        resource[attr] = new int[itemNum];
        index = 0;
        for (int item = 0; item < ins.itemNum; ++item) {
            if (isFixed[item] == 0) {
                resource[attr][index] = ins.resource[attr][item];
                index++;
            }
            else if (isFixed[item] == 1) {
                threshold[attr] = threshold[attr] - ins.resource[attr][item];
            }
        }
    }
}

SubInstance::SubInstance(int itemNum, int upperNum, int floorNum, int totalItemNum) {
    insName = " ";
    this->itemNum = itemNum;
    this->upperNum = upperNum;
    this->floorNum = floorNum;
    this->mainItemNum = totalItemNum;
    attrNum = upperNum + floorNum;
    leaveObj = 0;
    profit = new int[itemNum];
    threshold = new int[attrNum];
    attrType = new int[attrNum];
    resource = new int* [attrNum];
    fixed = new int[totalItemNum];
    for (int attr = 0; attr < attrNum; ++attr) {
        resource[attr] = new int[itemNum];
    }
}

void SubInstance::beCovered(const SubInstance& ins, int total) {
    if (itemNum != ins.itemNum) {
        cerr << "The covered inss has different item number!" << endl;
    }
    if (attrNum != ins.attrNum) {
        cerr << "The covered inss has different attr number!" << endl;
    }
    insName = ins.insName;
    leaveObj = ins.leaveObj;
    for (int item = 0;item < itemNum;item++) {
        profit[item] = ins.profit[item];
    }
    for (int attr = 0; attr < attrNum; ++attr) {
        threshold[attr] = ins.threshold[attr];
        attrType[attr] = ins.attrType[attr];
        for (int item = 0;item < itemNum;item++) {
            resource[attr][item] = ins.resource[attr][item];
        }
    }
    for (int item = 0;item < total;item++) {
        fixed[item] = ins.fixed[item];
    }
}

SubInstance::~SubInstance() {
    delete[] fixed;
}

Solution::Solution(const Instance& ins, float gammaBase, float gammaDelta) {
    this->gammaBase = gammaBase;
    this->gammaDelta = gammaDelta;
    feaNum = -1;
    itemNum = ins.itemNum;
    attrNum = ins.attrNum;
    select = new bool[ins.itemNum];
    occupy = new int[ins.attrNum];
    attrFeasible = new int[ins.attrNum];
    attrGamma = new double[ins.attrNum];
    tabuLoc = new long long [3] {0, 0, 0};
    for (int attr = 0; attr < ins.attrNum; ++attr) {
        attrFeasible[attr] = 0;
        occupy[attr] = 0;
        attrGamma[attr] = gammaBase;
    }
}

void Solution::initialize_random(const Instance& ins) {
    for (int item = 0; item < ins.itemNum; item++) {
        select[item] = rand() % 2;
    }
    evaluate(ins);
}

void Solution::initialize_matrix(const Instance& ins, float* matrix) {
    // creat a random sequence
    int* sequence = new int[ins.itemNum];
    vector<int> locIsEmpty;
    for (int item = 0; item < ins.itemNum; item++) {
        sequence[item] = -1;
        locIsEmpty.push_back(item);
    }
    for (int item = 0; item < ins.itemNum; item++) {
        int r = rand() % (locIsEmpty.size());
        sequence[locIsEmpty[r]] = ins.itemNum - 1 - item;
        locIsEmpty.erase(locIsEmpty.begin() + r);
    }
    // select item in sequence by matrix
    for (int index = 0;index < ins.itemNum;++index) {
        int item = sequence[index];
        float randomFloat = 1.0 * (rand() % 1000 + 1) / 1000;
        if (randomFloat < matrix[item]) {
            select[item] = 1;
        }
        else {
            select[item] = 0;
        }
    }
    delete[] sequence;
    evaluate(ins);
}

Solution::~Solution() {
    delete[] select;
    delete[] attrFeasible;
    delete[] occupy;
    delete[] attrGamma;
}

void Solution::printInformation(Output& output) const {
    output.output_info += Output::formato("The obj") + to_string(obj) + "\n";
    output.output_info += Output::formato("The fea") + to_string(feasible) + "\n";
    output.output_info += Output::formato("The feaNum") + to_string(feaNum) + "\n";
    output.output_info += Output::formato("The eva") + to_string(eva) + "\n";
}

void Solution::evaluate(const Instance& ins) {
    obj = 0;
    k = 0;
    for (int item = 0; item < itemNum; ++item) {
        obj += select[item] * ins.profit[item];
        k += select[item];
    }
    feasible = 0;
    feaNum = 0;
    for (int attr = 0; attr < ins.attrNum; ++attr) {
        int tempResource = 0;
        for (int item = 0; item < itemNum; ++item) {
            tempResource += select[item] * ins.resource[attr][item];
        }
        occupy[attr] = tempResource;
        attrFeasible[attr] = ins.attrType[attr] * (ins.threshold[attr] - tempResource);
        if (attrFeasible[attr] < 0) {
            feaNum++;
            feasible += -attrFeasible[attr] * attrGamma[attr];
        }
    }
    eva = 1.0 * obj - feasible;
}

void Solution::printSol(const Instance& ins) const {
    cout << "Solution:" << endl;
    for (int item = 0; item < itemNum; ++item) {
        printf("%5d(%d)  ", ins.profit[item], select[item]);
    }
    cout << "= " << obj << endl;
    for (int attr = 0; attr < ins.attrNum; ++attr) {
        for (int item = 0; item < itemNum; ++item) {
            printf("%5d(%d)  ", ins.resource[attr][item], select[item]);
        }
        cout << "= " << attrFeasible[attr] << endl;

    }
}

void Solution::destroy(const Instance& ins, float rate) {
    int destroy_num = itemNum * rate;
    while (destroy_num > 0) {
        destroy_num--;
        int item_index = rand() % itemNum;
        select[item_index] = 1 - select[item_index];
        int status = select[item_index] * 2 - 1;
        k += status;
        for (int attr = 0; attr < ins.attrNum; ++attr) {
            attrFeasible[attr] = attrFeasible[attr] - ins.attrType[attr] * ins.resource[attr][item_index] * status;
        }
        obj += status * ins.profit[item_index];
    }
    double temp = 0;
    feaNum = 0;
    for (int attr = 0; attr < ins.attrNum; ++attr) {
        if (attrFeasible[attr] < 0) {
            feaNum++;
            temp += -attrFeasible[attr] * attrGamma[attr];
            attrGamma[attr] += gammaDelta;
        }
    }
    feasible = temp;
    eva = obj - feasible;
    if (feasible == 0) {
        for (int attr = 0; attr < attrNum; ++attr) {
            attrGamma[attr] = gammaBase;
        }
    }
    gamma = 0;
    for (int attr = 0; attr < attrNum; ++attr) {
        gamma += attrGamma[attr];
    }
}

void Solution::execute_new(const Instance& ins, Move_new oper) {
    double temp = 0;
    feaNum = 0;
    for (int item = 0;item < oper.itemNum;++item) {
        select[oper.items[item]] = 1 - select[oper.items[item]];
        k += oper.status[item];
    }
    for (int attr = 0; attr < ins.attrNum; ++attr) {
        for (int item = 0;item < oper.itemNum;++item) {
            attrFeasible[attr] = attrFeasible[attr] - ins.attrType[attr] * ins.resource[attr][oper.items[item]] * oper.status[item];
        }
    }
    for (int attr = 0; attr < ins.attrNum; ++attr) {
        if (attrFeasible[attr] < 0) {
            feaNum++;
            temp += -attrFeasible[attr] * attrGamma[attr];
            attrGamma[attr] += gammaDelta;
        }
    }
    obj = oper.obj;
    feasible = temp;
    eva = obj - feasible;
    if (feaNum != oper.feaNum) {//temp != feasible ||
        cout << "Execute has mistake in iter " << temp << "//" << feasible << endl;
        cout << "Execute has mistake         " << feaNum << "//" << oper.feaNum << endl;
        Output_fun::printOper(oper);
        throw(-1);
    }
    if (feasible == 0) {
        for (int attr = 0; attr < attrNum; ++attr) {
            attrGamma[attr] = gammaBase;
        }
    }
    gamma = 0;
    for (int attr = 0; attr < attrNum; ++attr) {
        gamma += attrGamma[attr];
    }
}

void Solution::beCovered(const Solution& sol) {
    k = sol.k;
    obj = sol.obj;
    feasible = sol.feasible;
    eva = sol.eva;
    feaNum = sol.feaNum;
    gamma = sol.gamma;
    for (int item = 0; item < itemNum; ++item) {
        select[item] = sol.select[item];
    }
    for (int attr = 0; attr < attrNum; ++attr) {
        occupy[attr] = sol.occupy[attr];
        attrFeasible[attr] = sol.attrFeasible[attr];
        attrGamma[attr] = sol.attrGamma[attr];
    }
    for (int loc = 0; loc < 3; ++loc) {
        tabuLoc[loc] = sol.tabuLoc[loc];
    }

}

void Solution::output(const string& file, const Instance& ins) const {
    ofstream dataFile;
    dataFile.open(file);// ׷   ofstream::app
    if (!dataFile.is_open()) {
        fprintf(stderr, "Can not open file %s\n", file.c_str());
        exit(10);
    }
    //    dataFile << "vertexNumber "<<"edgeNumber "<<"objectValue "<<"injection(candidateGraphVertex : hostGraphIndex)"<<endl;
    dataFile << itemNum << " " << ins.upperNum << " " << ins.floorNum << " " << obj << endl;
    for (int item = 0; item < itemNum; ++item) {
        dataFile << select[item] << endl;
    }
    dataFile.close();
}

void Solution::check(const Instance& ins, Output& output) const {
    int judge = 0;
    int obj_check = 0;
    for (int item = 0; item < itemNum; ++item) {
        obj_check += select[item] * ins.profit[item];
    }
    if (obj_check != obj) {
        judge = 1;
    }
    for (int attr = 0; attr < attrNum; ++attr) {
        int tempOccupy = 0;
        for (int item = 0; item < itemNum; ++item) {
            tempOccupy += select[item] * ins.resource[attr][item];
        }
        if (ins.attrType[attr] == 1 && tempOccupy > ins.threshold[attr]) {
            judge = 2;
        }
        else if (ins.attrType[attr] != 1 && tempOccupy < ins.threshold[attr]) {
            judge = 3;
        }
    }
    output.output_info += Output::formato("Thc check");
    if (judge == 0) {
        output.output_info += "No mistake!!\n";
    }
    else if (judge == 1) {
        output.output_info += "Obj has mistake!!\n";
    }
    else if (judge == 2) {
        output.output_info += "upper limit!!\n";
    }
    else {
        output.output_info += "floor limit!!\n";
    }

}

void Solution::save_solution(const Instance& ins, Output& output) const {
    output.sol_temp += ins.insName + " " + to_string(obj) + " ";
    for (int item = 0; item < itemNum; ++item) {
        output.sol_temp += to_string(select[item]);
    }
    output.sol_temp += "\n\n";
}

void Solution::getTabuScore(const long long* weight1, const long long* weight2, const long long* weight3) const {
    tabuLoc[0] = 0;
    tabuLoc[1] = 0;
    tabuLoc[2] = 0;
    for (int item = 0;item < itemNum;item++) {
        if (select[item]) {
            tabuLoc[0] += weight1[item];
            tabuLoc[1] += weight2[item];
            tabuLoc[2] += weight3[item];
        }
    }
}

void Solution::restoreSol(const Solution& subSol, const Instance& mainIns, const SubInstance& subIns) {
    int subIndex = 0;
    for (int item = 0; item < itemNum; ++item) {
        if (subIns.fixed[item] == 0) {
            select[item] = subSol.select[subIndex++];
        }
        else {
            select[item] = (subIns.fixed[item] + 1) / 2;
        }
    }
    evaluate(mainIns);
    if (obj != subSol.obj + subIns.leaveObj) {
        cout << "Restoring has mistake!" << endl;
    }
}

ILP::ILP(const Instance& ins) {
    size = ins.itemNum;
    x = new float[size];
    scoreX = new float[size];
    k = 0;
    intNum = size;
    IloEnv env;
    try {
        // Add variable
        //ILOFLOAT,ILOINT,ILOBOOL is float,int,bool
        IloNumVarArray vars(env);
        for (int item = 0;item < ins.itemNum;item++) {
            vars.add(IloNumVar(env, 0, 1, ILOFLOAT));
            // vars.add(IloNumVar(env, 0, INFINITY, ILOFLOAT));
        }
        // Add constraint
        IloModel model(env);
        //for (int item = 0;item < ins.itemNum;item++) {
        //	model.add(vars[item] <= 1);
        //}
        for (int attr = 0;attr < ins.attrNum;attr++) {
            IloExpr expr(env);
            for (int item = 0; item < ins.itemNum; item++) {
                expr += vars[item] * ins.resource[attr][item];
            }
            if (ins.attrType[attr] == 1) {
                model.add(expr <= ins.threshold[attr]);
            }
            else {
                model.add(expr >= ins.threshold[attr]);
            }
        }
        // Add objective
        IloExpr obj(env);
        for (int item = 0; item < ins.itemNum; item++) {
            obj += vars[item] * ins.profit[item];
        }
        model.add(IloMaximize(env, obj));
        // solve
        IloCplex cplex(model);
        cplex.setOut(env.getNullStream());
        if (!cplex.solve()) {
            env.error() << "Failed to optimize LP." << endl;
            throw(-1);
        }
        IloNumArray vals(env);
        objValue = cplex.getObjValue();
        cplex.getValues(vals, vars);
        for (int index = 0;index < ins.itemNum;index++) {
            x[index] = vals[index];
            k += vals[index];
            if (vals[index] > 0 && vals[index] < 1) {
                intNum--;
            }
        }
    }
    catch (IloException& e) {
        cerr << "Concert exception caught: " << e << endl;
    }
    catch (...) { cerr << "Unknown exception caught" << endl; }

    env.end();
}

void ILP::printILP() {
    printf("the object value: %.2f\n", objValue);
    printf("the k value     : %.2f\n", k);
    printf("the int item num: %d\n", intNum);
}

void ILP::calculate(const Solution& sol) {
    if (sol.itemNum != size) {
        cerr << "The size of relax solution and feasible solution are different!!" << size << "/" << sol.itemNum << endl;
    }
    for (int item = 0;item < size;item++) {
        scoreX[item] = 1.0 - abs(x[item] - sol.select[item]);
    }
}

void ILP::restoreILP(ILP& subsolver, const SubInstance& subIns) {
    int subIndex = 0;
    for (int item = 0; item < size; ++item) {
        if (subIns.fixed[item] == 0) {
            scoreX[item] = subsolver.scoreX[subIndex];
            subIndex++;
        }
        else {
            scoreX[item] = 0.95;
        }
    }
}

ILP::~ILP() {
    delete[] x;
    delete[] scoreX;
}

class Sort {
public:
    Sort(const float* vector, int length);
    ~Sort();
    static void MergeSort(float* a, int* b, int left, int right);
    static void SingleLevelSort(float* a, int* b, int left, int right);
    float* data{};
    int* index{};
};

Frequency::Frequency(const Instance& ins) {
    size = ins.itemNum;
    freq = new int[size];
    isFixed = new int[size];
    score = new float[size];
    initial();
}

void Frequency::initial(const ILP& solver) {
    rate = 1.0;
    iter = 10000;
    k = solver.k;
    for (int item = 0;item < solver.size;item++) {
        double temp = solver.x[item];
        if (rand() % 10 > 8) {
            freq[item] = int(temp * iter);
        }
        else {
            freq[item] = int(0.5 * iter);
        }
    }
}

void Frequency::initial() {
    rate = 1;
    fixNum = 0;
    iter = 0;
    total = 0;
    lastSolFea = false;
    for (int item = 0; item < size; ++item) {
        freq[item] = 0;
        score[item] = 0;
    }
}

Frequency::~Frequency() {
    delete[] freq;
    delete[] isFixed;
    delete[] score;
}

void Frequency::updateFreq(Solution& sol) {
    iter++;
    for (int item = 0; item < size; ++item) {
        if (sol.select[item] == 1) {
            freq[item] += 1;
        }
    }
}

void Frequency::getFreqScore() {
    int f;
    if (iter != 0) {
        for (int item = 0; item < size; ++item) {
            f = iter - freq[item];
            if (f < freq[item]) {
                score[item] = 1.0 * (freq[item] - f) / (iter);
            }
            else {
                score[item] = 1.0 * (f - freq[item]) / (iter);
            }
            freq[item] = 0;
        }
    }
    iter = 0;
}

void Frequency::updateFixed() {
    int* state = new int[size] {0};
    int f;
    if (iter != 0) {
        for (int item = 0; item < size; ++item) {
            isFixed[item] = 0;
            f = iter - freq[item];
            if (f < freq[item]) {
                score[item] = score[item] + 1.0 * (freq[item] - f) / (iter);
                state[item] = 1;
            }
            else {
                score[item] = score[item] + 1.0 * (f - freq[item]) / (iter);
                state[item] = -1;
            }
            freq[item] = 0;
        }
    }
    Sort s(score, size);
    for (int fix = size - 1; fix >= size - fixNum; --fix) {
        isFixed[s.index[fix]] = state[s.index[fix]];
    }

    delete[] state;
}
void Frequency::updateFixed(const bool* select, float* scoreX, int* fixedFreq, int iter, float fixRate_, float scoreWeight) {
    for (int item = 0; item < size; ++item) {
        score[item] = score[item] * scoreWeight + scoreX[item] * (1 - scoreWeight);
        if (isFixed[item] != 0) {
            score[item] = score[item] * score[item];
        }
        score[item] = score[item] + (1 - score[item]) * (iter * iter - fixedFreq[item] * fixedFreq[item]) / (iter * iter + 1);
    }
    for (int item = 0; item < size; ++item) {
        isFixed[item] = 0;
    }
    Sort s(score, size);
    int fix = size - 1;
    fixNum = 0;
    fixRate = fixRate_;
    int the = (size - (int(size * fixRate)));
    while (fixNum < size && fixNum < the) {
        isFixed[s.index[fix]] = 2 * select[s.index[fix]] - 1;
        fix--;
        fixNum++;
    }
}

void Frequency::destruction(float rate, const bool* select) {
    int change = this->fixNum * rate;
    for (int item = 0;item < change;item++) {
        int loc = rand() % size;
        int status = 2 * select[loc] - 1;
        this->isFixed[loc] = status;
    }
}

void Frequency::restoreFreq(Frequency& subFreq, const SubInstance& subIns) {
    iter = subFreq.iter;
    lastSolFea = subFreq.lastSolFea;
    total += iter;
    int subIndex = 0;
    for (int item = 0; item < size; ++item) {
        if (subIns.fixed[item] == 0) {
            freq[item] = subFreq.freq[subIndex++];
        }
        else if (subIns.fixed[item] == 1) {
            freq[item] = int(subFreq.iter * 0.95);
        }
        else if (subIns.fixed[item] == -1) {
            freq[item] = int(subFreq.iter * 0.05);
        }
    }
}

void Frequency::flipFixed(const Solution& sol) const {
    for (int item = 0; item < size; ++item) {
        if (isFixed[item] != 0) {
            isFixed[item] = 0;
        }
        else {
            if (sol.select[item]) {
                isFixed[item] = 1;
            }
            else {
                isFixed[item] = -1;
            }
        }
    }
}

void Sort::SingleLevelSort(float* a, int* b, int left, int right) {
    int mid = (left + right) / 2;
    int begin1 = left, end1 = mid;
    int begin2 = mid + 1, end2 = right;
    int size = right - left + 1;
    auto* tmp = new float[size];
    auto* tmp2 = new int[size];
    int p = 0;
    while (begin1 <= end1 && begin2 <= end2)
    {
        if (a[begin1] > a[begin2])
        {
            tmp2[p] = b[begin2];
            tmp[p++] = a[begin2++];
        }
        else
        {
            tmp2[p] = b[begin1];
            tmp[p++] = a[begin1++];
        }
    }
    while (begin1 <= end1)
    {
        tmp2[p] = b[begin1];
        tmp[p++] = a[begin1++];
    }
    while (begin2 <= end2)
    {
        tmp2[p] = b[begin2];
        tmp[p++] = a[begin2++];
    }
    for (size_t i = 0; i < size; i++)
    {
        b[left + i] = tmp2[i];
        a[left + i] = tmp[i];
    }
    delete[] tmp;
    delete[] tmp2;
}

void Sort::MergeSort(float* a, int* b, int left, int right) {
    if (left >= right)
    {
        return;
    }
    int mid = (left + right) / 2;
    MergeSort(a, b, left, mid);
    MergeSort(a, b, mid + 1, right);
    SingleLevelSort(a, b, left, right);
}

Sort::Sort(const float* vector, int length) {
    data = new float[length];
    index = new int[length];
    for (int i = 0; i < length; ++i) {
        data[i] = vector[i];
        index[i] = i;
    }
    MergeSort(data, index, 0, length - 1);
}

Sort::~Sort() {
    delete[] data;
    delete[] index;
}

Qlearning_ex::Qlearning_ex(string par, string cand,float a,float r) {
    alpha = a;
    gamma = r;
    oper = 0;
    name = par;
    unsigned int loc = 0;
    size = 0;
    while (cand[loc] != '\0') {
        if (cand[loc] == ' ') {
            size++;
        }
        loc++;
    }
    candidate = new float[size] {};
    matrix = new float* [size];
    for (int i = 0;i < size;++i) {
        matrix[i] = new float[size] {};
    }
    loc = 0;
    unsigned int num = 0;
    unsigned int begin = 0;
    while (cand[loc] != '\0') {
        if (cand[loc] == ' ') {
            candidate[num++] = stof(cand.substr(begin, loc - begin));
            begin = loc;
        }
        loc++;
    }
    state = 1;
    oper = 1;
}

Qlearning_ex::~Qlearning_ex() {
    delete[] candidate;
    candidate = NULL;
    for (int i = 0;i < size;++i) {
        delete[] matrix[i];
        matrix[i] = NULL;
    }
    delete[] matrix;
    matrix = NULL;
}

void Qlearning_ex::selectOper() {
    int max_value_loc[100]{};
    int max_value_num = 0;
    float max_value = -9999;
    for (int i = 0;i < size;++i) {
        if (matrix[state][i] > max_value) {
            max_value = matrix[state][i];
            max_value_num = 0;
            max_value_loc[max_value_num++] = i;
        }
        else if (matrix[state][i] == max_value) {
            max_value_loc[max_value_num++] = i;
        }
    }
    if (max_value_num > 0) {
        int x = rand() % 1000;
        if (x < 800) {
            oper = max_value_loc[rand() % max_value_num];
        }
        else {
            oper = rand() % size;
        }
    }
    else {
        oper = -1;
        cout << endl << "-----cannot find max value in Qlearning matrix!----" << endl;
    }
}

float Qlearning_ex::update(int oldObj, int oldinfea, int newObj, int newinfea) {
    float reward = 0.0;
    if (newinfea - oldinfea == 0) {
        if (newObj > oldObj) {
            reward = 0.5;
        }
        else if (newObj < oldObj) {
            reward = -0.5;
        }
        else {
            reward = -0.2;
        }
    }
    else {
        reward = 0.1 * (oldinfea - newinfea);
    }
    int nextState = oper;
    float max_value = -9999;
    for (int i = 0;i < size;++i) {
        if (matrix[nextState][i] > max_value) {
            max_value = matrix[nextState][i];
        }
    }
    matrix[state][oper] = (1 - alpha) * matrix[state][oper] + alpha * (reward + gamma * max_value);
    state = nextState;
    selectOper();
    return candidate[state];
}

void Qlearning_ex::getResult() {
    float maxValue = -9999;
    int max_value_loc[100]{};
    int max_value_num = 0;
    for (int i = 0;i < size;++i) {
        if (matrix[i][i] > maxValue) {
            maxValue = matrix[i][i];
            max_value_num = 0;
            max_value_loc[max_value_num++] = i;
        }
        else if (matrix[i][i] == maxValue) {
            max_value_loc[max_value_num++] = i;
        }
    }
    res = candidate[max_value_loc[rand() % max_value_num]];
}

string Qlearning_ex::output() {
    string info = "";
    info += Output::formato("Q-learning state/oper") + to_string(state) + "|" + to_string(oper) + "\n";
    info += Output::formato("Q-learning Name") + name + "\n";
    info += Output::formato("Q-learning Candidate");
    for (int i = 0;i < size;++i) {
        info += to_string(candidate[i]) + "  ";
    }
    info += "\n";
    info += Output::formato("Q-learning Result") + to_string(res) + "\n";
    info += Output::formato("Q-learning Matrix") + "\n";
    for (int i = 0;i < size;++i) {
        info += Output::formato("Q-learning");
        for (int j = 0;j < size;++j) {
            string temp = Output::formatf(matrix[i][j], 10);
            info += temp;
        }
        info += "\n";
    }
    return info;
}

void Func::printVector(int* vector, int size) {
    for (int index = 0;index < size;index++) {
        printf("index %3d: %7d\n", index, vector[index]);
    }
}

void Func::updateOpers(vector<Move_new>& operators, Move_new oper) {
    if (operators.empty()) {
        operators.clear();
        operators.push_back(oper);
    }
    else {

        if (oper.attrNum != operators[0].attrNum) {
            //cout << 1 << endl;
            if (oper.obj > operators[0].obj) {
                operators.clear();
                operators.push_back(oper);
            }
            else if (oper.obj == operators[0].obj) {
                operators.push_back(oper);
            }
        }
        else {
            if (oper.eva > operators[0].eva) {
                operators.clear();
                operators.push_back(oper);
            }
            else if (oper.eva == operators[0].eva) {
                operators.push_back(oper);
            }
        }
    }
}


void Func::read(const string& path, const string& insNames, vector <string>& files) {
    const char* file = insNames.c_str();
    ifstream inputFile(file);
    if (!inputFile) {
        fprintf(stderr, "Can not open file %s\n", file);
        exit(10);
    }
    string temp;
    while (getline(inputFile, temp)) {
        files.push_back(path + "/" + temp);
    }
    inputFile.close();
}

map<string, int> Func::getBestKown() {
    // 20240531
    map<string, int> best{};
    best["100-10-10-0-0.txt"] = 22054;
    best["100-10-10-0-1.txt"] = 20103;
    best["100-10-10-0-2.txt"] = 19381;
    best["100-10-10-0-3.txt"] = 17434;
    best["100-10-10-0-4.txt"] = 18833;
    best["100-10-10-0-5.txt"] = 33837;
    best["100-10-10-1-0.txt"] = 8560;
    best["100-10-10-1-1.txt"] = 8493;
    best["100-10-10-1-2.txt"] = 9266;
    best["100-10-10-1-3.txt"] = 9823;
    best["100-10-10-1-4.txt"] = 8929;
    best["100-10-10-1-5.txt"] = 14152;
    best["100-10-5-0-0.txt"] = 21852;
    best["100-10-5-0-1.txt"] = 20645;
    best["100-10-5-0-2.txt"] = 19517;
    best["100-10-5-0-3.txt"] = 20596;
    best["100-10-5-0-4.txt"] = 19423;
    best["100-10-5-0-5.txt"] = 35933;
    best["100-10-5-1-0.txt"] = 10018;
    best["100-10-5-1-1.txt"] = 9839;
    best["100-10-5-1-2.txt"] = 10000;
    best["100-10-5-1-3.txt"] = 10544;
    best["100-10-5-1-4.txt"] = 10011;
    best["100-10-5-1-5.txt"] = 16230;
    best["100-30-30-0-2-1.txt"] = 11312;
    best["100-30-30-0-2-10.txt"] = 24371;
    best["100-30-30-0-2-11.txt"] = 33472;
    best["100-30-30-0-2-12.txt"] = 32670;
    best["100-30-30-0-2-13.txt"] = 32942;
    best["100-30-30-0-2-14.txt"] = 35106;
    best["100-30-30-0-2-15.txt"] = 30930;
    best["100-30-30-0-2-2.txt"] = 9945;
    best["100-30-30-0-2-3.txt"] = 11195;
    best["100-30-30-0-2-4.txt"] = 11324;
    best["100-30-30-0-2-5.txt"] = 9704;
    best["100-30-30-0-2-6.txt"] = 23296;
    best["100-30-30-0-2-7.txt"] = 22442;
    best["100-30-30-0-2-8.txt"] = 23452;
    best["100-30-30-0-2-9.txt"] = 22756;
    best["100-30-30-1-5-1.txt"] = 5340;
    best["100-30-30-1-5-10.txt"] = 10297;
    best["100-30-30-1-5-11.txt"] = 11029;
    best["100-30-30-1-5-12.txt"] = 11884;
    best["100-30-30-1-5-13.txt"] = 10751;
    best["100-30-30-1-5-14.txt"] = 11567;
    best["100-30-30-1-5-15.txt"] = 10671;
    best["100-30-30-1-5-2.txt"] = 4390;
    best["100-30-30-1-5-3.txt"] = 4227;
    best["100-30-30-1-5-4.txt"] = 4706;
    best["100-30-30-1-5-5.txt"] = 2597;
    best["100-30-30-1-5-6.txt"] = 10808;
    best["100-30-30-1-5-7.txt"] = 9807;
    best["100-30-30-1-5-8.txt"] = 10882;
    best["100-30-30-1-5-9.txt"] = 10595;
    best["100-5-2-0-0.txt"] = 28384;
    best["100-5-2-0-1.txt"] = 26386;
    best["100-5-2-0-2.txt"] = 23484;
    best["100-5-2-0-3.txt"] = 27374;
    best["100-5-2-0-4.txt"] = 30632;
    best["100-5-2-0-5.txt"] = 44674;
    best["100-5-2-1-0.txt"] = 10379;
    best["100-5-2-1-1.txt"] = 11114;
    best["100-5-2-1-2.txt"] = 10124;
    best["100-5-2-1-3.txt"] = 10567;
    best["100-5-2-1-4.txt"] = 10658;
    best["100-5-2-1-5.txt"] = 17550;
    best["100-5-5-0-0.txt"] = 21892;
    best["100-5-5-0-1.txt"] = 26280;
    best["100-5-5-0-2.txt"] = 20628;
    best["100-5-5-0-3.txt"] = 21547;
    best["100-5-5-0-4.txt"] = 25074;
    best["100-5-5-0-5.txt"] = 40327;
    best["100-5-5-1-0.txt"] = 10263;
    best["100-5-5-1-1.txt"] = 10625;
    best["100-5-5-1-2.txt"] = 10198;
    best["100-5-5-1-3.txt"] = 10030;
    best["100-5-5-1-4.txt"] = 9964;
    best["100-5-5-1-5.txt"] = 15603;
    best["250-10-10-0-0.txt"] = 52442;
    best["250-10-10-0-1.txt"] = 53745;
    best["250-10-10-0-2.txt"] = 46927;
    best["250-10-10-0-3.txt"] = 54856;
    best["250-10-10-0-4.txt"] = 49699;
    best["250-10-10-0-5.txt"] = 93006;
    best["250-10-10-1-0.txt"] = 26696;
    best["250-10-10-1-1.txt"] = 25876;
    best["250-10-10-1-2.txt"] = 26517;
    best["250-10-10-1-3.txt"] = 26684;
    best["250-10-10-1-4.txt"] = 26676;
    best["250-10-10-1-5.txt"] = 42629;
    best["250-10-5-0-0.txt"] = 56327;
    best["250-10-5-0-1.txt"] = 59619;
    best["250-10-5-0-2.txt"] = 55034;
    best["250-10-5-0-3.txt"] = 52416;
    best["250-10-5-0-4.txt"] = 58234;
    best["250-10-5-0-5.txt"] = 99752;
    best["250-10-5-1-0.txt"] = 26976;
    best["250-10-5-1-1.txt"] = 26684;
    best["250-10-5-1-2.txt"] = 25749;
    best["250-10-5-1-3.txt"] = 27181;
    best["250-10-5-1-4.txt"] = 26856;
    best["250-10-5-1-5.txt"] = 46244;
    best["250-5-2-0-0.txt"] = 78486;
    best["250-5-2-0-1.txt"] = 75132;
    best["250-5-2-0-2.txt"] = 71003;
    best["250-5-2-0-3.txt"] = 80311;
    best["250-5-2-0-4.txt"] = 70935;
    best["250-5-2-0-5.txt"] = 130981;
    best["250-5-2-1-0.txt"] = 26666;
    best["250-5-2-1-1.txt"] = 26864;
    best["250-5-2-1-2.txt"] = 27280;
    best["250-5-2-1-3.txt"] = 26269;
    best["250-5-2-1-4.txt"] = 27293;
    best["250-5-2-1-5.txt"] = 44419;
    best["250-5-5-0-0.txt"] = 68026;
    best["250-5-5-0-1.txt"] = 60795;
    best["250-5-5-0-2.txt"] = 62093;
    best["250-5-5-0-3.txt"] = 66657;
    best["250-5-5-0-4.txt"] = 61929;
    best["250-5-5-0-5.txt"] = 127934;
    best["250-5-5-1-0.txt"] = 26973;
    best["250-5-5-1-1.txt"] = 26665;
    best["250-5-5-1-2.txt"] = 26648;
    best["250-5-5-1-3.txt"] = 25923;
    best["250-5-5-1-4.txt"] = 26060;
    best["250-5-5-1-5.txt"] = 41372;
    best["500-30-30-0-2-1.txt"] = 85496;
    best["500-30-30-0-2-10.txt"] = 142237;
    best["500-30-30-0-2-11.txt"] = 185329;
    best["500-30-30-0-2-12.txt"] = 194660;
    best["500-30-30-0-2-13.txt"] = 208425;
    best["500-30-30-0-2-14.txt"] = 215944;
    best["500-30-30-0-2-15.txt"] = 194311;
    best["500-30-30-0-2-2.txt"] = 82334;
    best["500-30-30-0-2-3.txt"] = 77450;
    best["500-30-30-0-2-4.txt"] = 82420;
    best["500-30-30-0-2-5.txt"] = 83694;
    best["500-30-30-0-2-6.txt"] = 146154;
    best["500-30-30-0-2-7.txt"] = 152320;
    best["500-30-30-0-2-8.txt"] = 157794;
    best["500-30-30-0-2-9.txt"] = 154078;
    best["500-30-30-1-5-1.txt"] = 51689;
    best["500-30-30-1-5-10.txt"] = 82958;
    best["500-30-30-1-5-11.txt"] = 88887;
    best["500-30-30-1-5-12.txt"] = 87304;
    best["500-30-30-1-5-13.txt"] = 87315;
    best["500-30-30-1-5-14.txt"] = 87655;
    best["500-30-30-1-5-15.txt"] = 87965;
    best["500-30-30-1-5-2.txt"] = 50256;
    best["500-30-30-1-5-3.txt"] = 51226;
    best["500-30-30-1-5-4.txt"] = 51753;
    best["500-30-30-1-5-5.txt"] = 52224;
    best["500-30-30-1-5-6.txt"] = 84072;
    best["500-30-30-1-5-7.txt"] = 82952;
    best["500-30-30-1-5-8.txt"] = 82763;
    best["500-30-30-1-5-9.txt"] = 82831;
    best["1-1000-60-60-1.0-0.25-P.txt"] = 161913;
    best["2-1000-60-60-1.0-0.25-P.txt"] = 135462;
    best["3-1000-60-60-1.0-0.25-P.txt"] = 149528;
    best["4-1000-60-60-1.0-0.25-P.txt"] = 137242;
    best["5-1000-60-60-1.0-0.25-P.txt"] = 144981;
    best["6-1000-60-60-1.0-0.25-P.txt"] = 147475;
    best["7-1000-60-60-1.0-0.25-P.txt"] = 149211;
    best["8-1000-60-60-1.0-0.25-P.txt"] = 150717;
    best["9-1000-60-60-1.0-0.25-P.txt"] = 138286;
    best["10-1000-60-60-1.0-0.25-P.txt"] = 150463;
    best["1-1000-60-60-1.0-0.25-M.txt"] = 37185;
    best["2-1000-60-60-1.0-0.25-M.txt"] = 37663;
    best["3-1000-60-60-1.0-0.25-M.txt"] = 38384;
    best["4-1000-60-60-1.0-0.25-M.txt"] = 37662;
    best["5-1000-60-60-1.0-0.25-M.txt"] = 35122;
    best["6-1000-60-60-1.0-0.25-M.txt"] = 40245;
    best["7-1000-60-60-1.0-0.25-M.txt"] = 38676;
    best["8-1000-60-60-1.0-0.25-M.txt"] = 41226;
    best["9-1000-60-60-1.0-0.25-M.txt"] = 37209;
    best["10-1000-60-60-1.0-0.25-M.txt"] = 40701;
    best["1-1000-60-60-1.0-0.5-P.txt"] = 271149;
    best["2-1000-60-60-1.0-0.5-P.txt"] = 277188;
    best["3-1000-60-60-1.0-0.5-P.txt"] = 274581;
    best["4-1000-60-60-1.0-0.5-P.txt"] = 263410;
    best["5-1000-60-60-1.0-0.5-P.txt"] = 273797;
    best["6-1000-60-60-1.0-0.5-P.txt"] = 263449;
    best["7-1000-60-60-1.0-0.5-P.txt"] = 266557;
    best["8-1000-60-60-1.0-0.5-P.txt"] = 250148;
    best["9-1000-60-60-1.0-0.5-P.txt"] = 267853;
    best["10-1000-60-60-1.0-0.5-P.txt"] = 262383;
    best["1-1000-60-60-1.0-0.5-M.txt"] = 51390;
    best["2-1000-60-60-1.0-0.5-M.txt"] = 57839;
    best["3-1000-60-60-1.0-0.5-M.txt"] = 49144;
    best["4-1000-60-60-1.0-0.5-M.txt"] = 51463;
    best["5-1000-60-60-1.0-0.5-M.txt"] = 51251;
    best["6-1000-60-60-1.0-0.5-M.txt"] = 53082;
    best["7-1000-60-60-1.0-0.5-M.txt"] = 49378;
    best["8-1000-60-60-1.0-0.5-M.txt"] = 50321;
    best["9-1000-60-60-1.0-0.5-M.txt"] = 55300;
    best["10-1000-60-60-1.0-0.5-M.txt"] = 60547;
    best["1-1000-60-60-1.0-0.75-P.txt"] = 381747;
    best["2-1000-60-60-1.0-0.75-P.txt"] = 342056;
    best["3-1000-60-60-1.0-0.75-P.txt"] = 364665;
    best["4-1000-60-60-1.0-0.75-P.txt"] = 365192;
    best["5-1000-60-60-1.0-0.75-P.txt"] = 336282;
    best["6-1000-60-60-1.0-0.75-P.txt"] = 350571;
    best["7-1000-60-60-1.0-0.75-P.txt"] = 334829;
    best["8-1000-60-60-1.0-0.75-P.txt"] = 340098;
    best["9-1000-60-60-1.0-0.75-P.txt"] = 338964;
    best["10-1000-60-60-1.0-0.75-P.txt"] = 360288;
    best["1-1000-60-60-1.0-0.75-M.txt"] = 40674;
    best["2-1000-60-60-1.0-0.75-M.txt"] = 36706;
    best["3-1000-60-60-1.0-0.75-M.txt"] = 38097;
    best["4-1000-60-60-1.0-0.75-M.txt"] = 44221;
    best["5-1000-60-60-1.0-0.75-M.txt"] = 43633;
    best["6-1000-60-60-1.0-0.75-M.txt"] = 41005;
    best["7-1000-60-60-1.0-0.75-M.txt"] = 41863;
    best["8-1000-60-60-1.0-0.75-M.txt"] = 42230;
    best["9-1000-60-60-1.0-0.75-M.txt"] = 31740;
    best["10-1000-60-60-1.0-0.75-M.txt"] = 40686;
    return best;
}

void Run::set_single_input_parameters(map<string, float>& parameters, string ins, int itemNum) {
    // run single
    map<string, int> best = Func::getBestKown();
    if (best.count(ins) == 0) {
        parameters["KownBest"] = 0;
    }
    else {
        parameters["KownBest"] = best[ins];
    }
    parameters["itemNum"] = itemNum;
    parameters["experType"] = parameters["input_expr"];
    if (itemNum == 500) {
        parameters["timeTotalLimit"] = 500;
    }
    else if (itemNum == 1000) {
        parameters["timeTotalLimit"] = 1000;
    }
    else {
        parameters["timeTotalLimit"] = 300;
    }
    if (TIME_LIMIT > 0) {
        parameters["timeTotalLimit"] = TIME_LIMIT;
    }
    if (IFPRINT == 1) {
        parameters["if_print_iter_info"] = 1.0;
    }
    else {
        parameters["if_print_iter_info"] = 0.0;
    }

    parameters["impoveCut"] = 10000;
    parameters["subTimeLimit"] = 0.2 * parameters["timeTotalLimit"];
    parameters["firstTimeLimit"] = 0.5 * parameters["timeTotalLimit"];
    parameters["gamma"] = 0.2;
    parameters["gammaBase"] = parameters["gamma"] * 0.5;
    parameters["searchCut"] = 500;
    parameters["fristCut"] = 1000;
    parameters["fixRate"] = 0.1;
    parameters["coreAvg"] = 0.2;
    parameters["kdelta"] = 5.0;
}

void write_info(const string& path, const string& info) {
    ofstream dataFile;
    dataFile.open(path, ofstream::app);
    if (!dataFile.is_open()) {
        fprintf(stderr, "Can not open file %s\n", path.c_str());
        exit(10);
    }
    dataFile << info << endl;
    dataFile.close();
}

int Run::run_single(string path, string out_path, string now, int expr, int i) {
    time_t clock = time(NULL);
    Instance ins(path);
    int ss = (i - 1) % 9 + 1;
    int seed = expr + 2*((i-1)/9);//(int(clock) + i) % 11311 + (ins.profit[0] + 1) + (expr + 1) * 20 + 1;
    Input input(seed, now);
    input.parameters["input_expr"] = 51801;
    Run::set_single_input_parameters(input.parameters, ins.insName, ins.itemNum);
    // parameter 1
    input.parameters["tau"] = 0.1; //0.1
    input.parameters["firstTimeLimit"] = input.parameters["tau"] * input.parameters["timeTotalLimit"];
    // parameter 2
	int a[9] = {2,5,10,15,20,30,50,70,100};
    input.parameters["kdelta"] = a[ss-1]; // 5.0
    // parameter 3
    input.parameters["weight"] = 0.5;
    // parameter 4
    input.parameters["Q-gamma"] = 0.9;
    // parameter 5
    input.parameters["Q-alpha"] = 0.8;
    // parameter 6
    input.parameters["gamma"] = 0.2;
    input.parameters["gammaBase"] = input.parameters["gamma"] * 0.5;
    Solution sol(ins, input.parameters["gammaBase"], input.parameters["gamma"]);
    string info = SEARCH_Qlearning_ex(ins, sol, input);
    out_path += ins.insName + "_" + to_string(expr) + "_" + to_string(i) + "_" + to_string(seed) + ".txt";
    write_info(out_path, info);
    return int(input.parameters["delta"]);
}

void Run::run_ins_set(int re, string path, string ins_set, int expr) {
    vector <string> files;
    Func::read(path, ins_set, files);
    int repeat = re;
    int index = 0;// The number of distinct instances
    int times = 0;// The number of instances has repeated
    int n = 0;    // The number of runned instances
    string out_path = "../out/";
    string all_info = "";
    string title = "" + Output::format("begin time", 22) + Output::format("instance name", 30) + Output::format("ins index", 10) + Output::format("repeat nums", 12) + Output::format("total nums", 10) + Output::format("delta", 10);
    cout << title << endl;
    all_info = title + "\n";
    int sss = 0;
    int nnn = 0;
    while (times < repeat) {
        time_t now = time(NULL);
        string now1 = getTime0();
        int delta = -1;
        try {
            delta = Run::run_single(files[index], out_path, now1, times + expr, n + expr);
        }
        catch (const std::exception&) {
            cout << files[index] << " has mistake!" << endl;
        }

        string info = "" + Output::format(now1, 22) + Output::format(files[index], 30) + Output::formati(index + 1, 10) + Output::formati(times + 1, 12) + Output::formati(n + 1, 10);
        if (delta != -1) {
            info += Output::formati(delta, 10);
            sss += delta;
            nnn += 1;
        }
        cout << info << endl;
        all_info += info + "\n";
        if (n % 3 == 2) {
            try {
                write_info("C:/Users/GaoMi/OneDrive/code/out.txt", all_info);//GaoMi
            }
            catch (const std::exception&) {
                int a = 1;
            }

            cout << endl << title << endl;
            all_info = title + "\n";
        }
        clock_t end = clock();
        index++;
        n++;
        if (index == files.size()) {
            times++;
            index = 0;
        }
    }
    cout << endl << "avg_delta : " << sss << " / " << nnn << " = " << 1.0 * sss / nnn << endl;
}

void flipNeighbor_test(const Instance& ins, const Solution& sol, vector<Move_new>& operators, Tabu_Sol& tabu, Output& flipTime) {
    clock_t begin = clock();
    for (int item = 0; item < ins.itemNum; ++item) {
        Move_new oper;
        oper.update_oper(ins.attrNum, ins.profit[item], ins.resource, sol.select[item], item);
        oper.obj = sol.obj + oper.delta;
        for (int attr = 0; attr < ins.attrNum; ++attr) {
            long long attrFeasible;
            attrFeasible = sol.attrFeasible[attr] - ins.attrType[attr] * oper.attr_delta[attr];
            if (attrFeasible < 0) {
                oper.feaNum++;
                oper.feasible += -attrFeasible * sol.attrGamma[attr];
            }
        }
        oper.eva = oper.obj - oper.feasible;
        if (!tabu.judgeTabu_new(sol, oper)) {
            //cout << "jj" << endl;
            Func::updateOpers(operators, oper);
        }
    }
    clock_t end = clock();
    flipTime.flipTime += (double)(end - begin) / CLOCKS_PER_SEC;
}

void swapNeighbor_test(const Instance& ins, const Solution& sol, vector<Move_new>& operators, Tabu_Sol& tabu, Output& swapTime) {
    clock_t begin = clock();
    for (int inItem = 0; inItem < ins.itemNum; ++inItem) {
        if (sol.select[inItem] == 1) continue;
        Move_new before;
        before.update_oper(ins.attrNum, ins.profit[inItem], ins.resource, sol.select[inItem], inItem);
        for (int outItem = 0; outItem < ins.itemNum; ++outItem) {
            if (sol.select[outItem] == 0) continue;
            //clock_t a = clock();
            Move_new oper(before, ins.profit[outItem], ins.resource, sol.select[outItem], outItem);
            oper.obj = sol.obj + oper.delta;
            //clock_t b = clock();
            for (int attr = 0; attr < ins.attrNum; ++attr) {
                int attrFeasible;
                attrFeasible = sol.attrFeasible[attr] - ins.attrType[attr] * oper.attr_delta[attr];
                //swapTime.times["constrNum"] += 1;
                if (attrFeasible < 0) {
                    oper.feaNum++;
                    oper.feasible += -attrFeasible * sol.attrGamma[attr];
                }
            }
            oper.eva = oper.obj - oper.feasible;
            //clock_t c = clock();
            if (!tabu.judgeTabu_new(sol, oper)) {
                Func::updateOpers(operators, oper);
            }
        }
    }
    clock_t end = clock();
    swapTime.swapTime += (double)(end - begin) / CLOCKS_PER_SEC;
}

void firstSearch_new(const Instance& ins, Solution& sol, Frequency& fModel, Input& input, Output& output) {
    // This search input the main instance and output a feasible solution with the limit of time
    Solution tempSol(ins, input.parameters["gammaBase"], input.parameters["gamma"]);
    tempSol.beCovered(sol);
    Tabu_Sol tabu(ins.itemNum, input.parameters["experType"]);
    tempSol.getTabuScore(tabu.weight1, tabu.weight2, tabu.weight3);
    output.iter = 0;
    output.stagnant = 0;
    vector<Move_new> opers;
    bool condition = true;
    //cout << input.k << " / " << sol.k << endl;
    while (condition) {
        output.iter++;
        output.stagnant++;
        if (input.k - tempSol.k > input.parameters["kdelta"] || input.k - tempSol.k < -1 * input.parameters["kdelta"]) {
            flipNeighbor_test(ins, tempSol, opers, tabu, output);
        }
        else {
            flipNeighbor_test(ins, tempSol, opers, tabu, output);
            swapNeighbor_test(ins, tempSol, opers, tabu, output);
            //Neighbor_extend::nChange_follow(ins, tempSol, opers, tabu, output);
        }
        if (!opers.empty()) {
            int aa = rand() % opers.size();
            tempSol.execute_new(ins, opers[aa]);
            tempSol.getTabuScore(tabu.weight1, tabu.weight2, tabu.weight3);
            fModel.updateFreq(tempSol);
            tabu.tabuSol(tempSol);
            output.tabuNum++;
            opers.clear();
            if ((((tempSol.feasible == 0 && sol.feasible == 0) || (tempSol.feasible != 0 && sol.feasible != 0)) && tempSol.eva > sol.eva) || (tempSol.feasible == 0 && sol.feasible != 0)) {
                sol.beCovered(tempSol);
                output.stagnant = 0;
                clock_t end = clock();
                output.findBestTime = (double)(end - output.beginTime) / CLOCKS_PER_SEC;
            }
        }
        clock_t end = clock();
        output.totalTime = (double)(end - output.beginTime) / CLOCKS_PER_SEC;
        if (input.parameters["step"] <= 1.0) {
            //condition = ((sol.feaNum != 0) && output.totalTime < input.parameters["firstTimeLimit"]);
            condition = ((sol.feaNum != 0 || output.stagnant < input.parameters["fristCut"]) && output.totalTime < input.parameters["firstTimeLimit"]);
        }
        else if (input.parameters["step"] <= 2.0) {
            condition = (output.stagnant < input.parameters["impoveCut"] && output.totalTime < input.parameters["subTimeLimit"]);
        }
        else if (input.parameters["step"] <= 3.0) {
            condition = (output.totalTime < input.parameters["subTimeLimit"]);
        }
    }
}

void SEARCH_new(Instance& ins, Solution& sol, Input& input) {
}

void SEARCH_base(Instance& ins, Solution& sol, Input& input) {
    Output output(input.parameters["if_print_iter_info"], input.now);
    float timeLimit = input.parameters["timeTotalLimit"];
    Frequency fModel(ins);
    ILP solver(ins);
    input.k = solver.k;
    while (sol.feaNum != 0 && output.totalTime < timeLimit) {
        input.parameters["step"] = 1.0;
        output.iter++;
        int beforeObj = sol.obj;
        int beforefea = sol.feaNum;
        fModel.initial();
        Output firstOutput(-1);
        sol.initialize_random(ins);
        firstSearch_new(ins, sol, fModel, input, firstOutput);
        output.getSubInfo(firstOutput);
        clock_t end = clock();
        output.totalTime = (double)(end - output.beginTime) / CLOCKS_PER_SEC;
        string tempStr = Output_fun::get_iter_info(input.parameters["if_print_iter_info"], output.iter, -1, firstOutput.iter, firstOutput.totalTime, output.totalTime, ins.itemNum, sol.obj, sol.obj, sol.feaNum, sol.k, sol.obj);
        output.iter_info += tempStr;
    }
    Solution tempSol(ins, input.parameters["gammaBase"], input.parameters["gamma"]);
    tempSol.beCovered(sol);
    solver.calculate(sol);
    fModel.getFreqScore();
    fModel.updateFixed(tempSol.select, solver.scoreX, ins.fixedFreq, ins.fixedIter, input.parameters["fixRate"]);
    while (output.totalTime < timeLimit && output.stagnant < input.parameters["searchCut"]) {
        output.iter++;
        output.stagnant++;
        if (timeLimit - output.totalTime > 0.5 * timeLimit) {
            input.parameters["subTimeLimit"] = 0.5 * (timeLimit - output.totalTime);
        }
        else {
            input.parameters["subTimeLimit"] = 1.0 * (timeLimit - output.totalTime) + 0.01;
        }
        input.parameters["step"] = 2.0;
        SubInstance sIns(ins, fModel.isFixed);
        Solution sSol(sIns, input.parameters["gammaBase"], input.parameters["gamma"]);
        Frequency subFModel(sIns);
        ILP subsolver(sIns);
        input.k = subsolver.k;
        sSol.initialize_random(sIns);
        subFModel.initial();
        Output secondOutput(-1);
        firstSearch_new(sIns, sSol, subFModel, input, secondOutput);
        tempSol.restoreSol(sSol, ins, sIns);
        if (tempSol.feaNum == 0) {
            if (tempSol.obj > sol.obj) {
                sol.beCovered(tempSol);
                output.stagnant = 0;
                clock_t end = clock();
                output.findBestTime = (double)(end - output.beginTime) / CLOCKS_PER_SEC;
            }
        }
        fModel.restoreFreq(subFModel, sIns);
        fModel.getFreqScore();
        subsolver.calculate(sSol);
        solver.restoreILP(subsolver, sIns);
        fModel.updateFixed(sol.select, solver.scoreX, ins.fixedFreq, ins.fixedIter, input.parameters["fixRate"]);
        output.getSubInfo(secondOutput);
        clock_t end = clock();
        output.totalTime = (double)(end - output.beginTime) / CLOCKS_PER_SEC;
        string tempStr = Output_fun::get_iter_info(input.parameters["if_print_iter_info"], output.iter, output.stagnant, secondOutput.iter, secondOutput.totalTime, output.totalTime, sIns.itemNum, sSol.obj, tempSol.obj, tempSol.feaNum, tempSol.k, sol.obj);
        output.iter_info += tempStr;
    }
    ins.printInformation(output);
    output.printOutput();
    sol.printInformation(output);
    output.output_info += "OutputTime reduce cost rate      : " + to_string(-1) + "\n";
    output.output_info += "OutputTime   fixedNum            : " + to_string(fModel.fixNum) + "\n";
    input.parameters["delta"] = input.parameters["KownBest"] - sol.obj;
    output.out_parameters(input.parameters);
    output.out_parameters(output.times);
    sol.check(ins, output);
    string outputPath = "../out/" + ins.insName + "_" + to_string(input.seed) + ".txt";//../out
    if (sol.feaNum == 0) {
        sol.save_solution(ins, output);
    }
    output.output(outputPath);
}

void SEARCH_Qlearning(Instance& ins, Solution& sol, Input& input) {
    Output output(input.parameters["if_print_iter_info"]);
    float timeLimit = input.parameters["timeTotalLimit"];
    Frequency fModel(ins);
    ILP solver(ins);
    input.k = solver.k;
    while (sol.feaNum != 0 && output.totalTime < timeLimit) {
        input.parameters["step"] = 1.0;
        output.iter++;
        int beforeObj = sol.obj;
        int beforefea = sol.feaNum;
        fModel.initial();
        Output firstOutput(-1);
        sol.initialize_random(ins);
        firstSearch_new(ins, sol, fModel, input, firstOutput);
        output.getSubInfo(firstOutput);
        clock_t end = clock();
        output.totalTime = (double)(end - output.beginTime) / CLOCKS_PER_SEC;
        string tempStr = Output_fun::get_iter_info(input.parameters["if_print_iter_info"], output.iter, -1, firstOutput.iter, firstOutput.totalTime, output.totalTime, ins.itemNum, sol.obj, sol.obj, sol.feaNum, sol.k, sol.obj);
        output.iter_info += tempStr;
    }
    Qlearning_ex f("fixRate", "0.00 0.05 0.1 0.15 0.2 0.25 0.3 ",input.parameters["Q-alpha"], input.parameters["Q-gamma"]);
    input.parameters["fixRate"] = f.candidate[f.state];
    Solution tempSol(ins, input.parameters["gammaBase"], input.parameters["gamma"]);
    tempSol.beCovered(sol);
    solver.calculate(sol);
    fModel.getFreqScore();
    fModel.updateFixed(tempSol.select, solver.scoreX, ins.fixedFreq, ins.fixedIter, input.parameters["fixRate"]);
    while (output.totalTime < timeLimit && output.stagnant < input.parameters["searchCut"]) {
        output.iter++;
        output.stagnant++;
        if (timeLimit - output.totalTime > 0.5 * timeLimit) {
            input.parameters["subTimeLimit"] = 0.5 * (timeLimit - output.totalTime);
        }
        else {
            input.parameters["subTimeLimit"] = 1.0 * (timeLimit - output.totalTime) + 0.01;
        }
        input.parameters["step"] = 2.0;
        int oldObj = tempSol.obj;
        int oldFea = tempSol.feaNum;
        SubInstance sIns(ins, fModel.isFixed);
        Solution sSol(sIns, input.parameters["gammaBase"], input.parameters["gamma"]);
        Frequency subFModel(sIns);
        ILP subsolver(sIns);
        input.k = subsolver.k;
        sSol.initialize_random(sIns);
        subFModel.initial();
        Output secondOutput(-1);
        firstSearch_new(sIns, sSol, subFModel, input, secondOutput);
        tempSol.restoreSol(sSol, ins, sIns);
        if (tempSol.feaNum == 0) {
            if (tempSol.obj > sol.obj) {
                sol.beCovered(tempSol);
                output.stagnant = 0;
                clock_t end = clock();
                output.findBestTime = (double)(end - output.beginTime) / CLOCKS_PER_SEC;
            }
        }
        input.parameters["fixRate"] = f.update(oldObj, oldFea, tempSol.obj, tempSol.feaNum);
        fModel.restoreFreq(subFModel, sIns);
        fModel.getFreqScore();
        subsolver.calculate(sSol);
        solver.restoreILP(subsolver, sIns);
        fModel.updateFixed(sol.select, solver.scoreX, ins.fixedFreq, ins.fixedIter, input.parameters["fixRate"]);
        output.getSubInfo(secondOutput);
        clock_t end = clock();
        output.totalTime = (double)(end - output.beginTime) / CLOCKS_PER_SEC;
        string tempStr = Output_fun::get_iter_info(input.parameters["if_print_iter_info"], output.iter, output.stagnant, secondOutput.iter, secondOutput.totalTime, output.totalTime, sIns.itemNum, sSol.obj, tempSol.obj, tempSol.feaNum, tempSol.k, sol.obj);
        output.iter_info += tempStr;
    }
    ins.printInformation(output);
    output.printOutput();
    sol.printInformation(output);
    output.output_info += "OutputTime reduce cost rate      : " + to_string(-1) + "\n";
    output.output_info += "OutputTime   fixedNum            : " + to_string(fModel.fixNum) + "\n";
    input.parameters["delta"] = input.parameters["KownBest"] - sol.obj;
    output.out_parameters(input.parameters);
    output.out_parameters(output.times);
    sol.check(ins, output);
    f.getResult();
    string Qinfo = f.output();
    output.output_info += Qinfo;
    string outputPath = "./out/" + ins.insName + "_" + to_string(input.seed) + ".txt";//../out
    if (sol.feaNum == 0) {
        sol.save_solution(ins, output);
    }
    output.output(outputPath);
}


string SEARCH_Qlearning_ex(Instance& ins, Solution& sol, Input& input) {
    Output output(input.parameters["if_print_iter_info"], input.now);
    float timeLimit = input.parameters["timeTotalLimit"];
    Frequency fModel(ins);
    ILP solver(ins);
    input.k = solver.k;
    //cout << "Begin!" << endl;
    while (sol.feaNum != 0 && output.totalTime < timeLimit) {
        input.parameters["step"] = 1.0;
        output.iter++;
        int beforeObj = sol.obj;
        int beforefea = sol.feaNum;
        fModel.initial();
        Output firstOutput(-1);
        sol.initialize_random(ins);
        //cout << "Begin first search! " << output.iter << endl;
        firstSearch_new(ins, sol, fModel, input, firstOutput);
        output.getSubInfo(firstOutput);
        clock_t end = clock();
        output.totalTime = (double)(end - output.beginTime) / CLOCKS_PER_SEC;
        string tempStr = Output_fun::get_iter_info(input.parameters["if_print_iter_info"], output.iter, -1, firstOutput.iter, firstOutput.totalTime, output.totalTime, ins.itemNum, sol.obj, sol.obj, sol.feaNum, sol.k, sol.obj);
        output.iter_info += tempStr;
    }
    //Qlearning_ex f("fixRate", "0.05 0.1 0.15 0.2 0.25 ");
    //Qlearning_ex f("fixRate", "0.05 0.075 0.1 0.125 0.15 ");
    //Qlearning_ex f("fixRate", "0.05 0.06 0.07 0.08 0.09 0.10 ");
    Qlearning_ex f("fixRate", "0.3 0.4 0.5 0.6 0.7 ", input.parameters["Q-alpha"], input.parameters["Q-gamma"]);
    input.parameters["fixRate"] = input.parameters["coreAvg"] * (0.5 + f.candidate[f.state]);
    Solution tempSol(ins, input.parameters["gammaBase"], input.parameters["gamma"]);
    tempSol.beCovered(sol);
    solver.calculate(sol);
    fModel.getFreqScore();
    fModel.updateFixed(tempSol.select, solver.scoreX, ins.fixedFreq, ins.fixedIter, input.parameters["fixRate"], input.parameters["weight"]);
    while (output.totalTime < timeLimit && output.stagnant < input.parameters["searchCut"]) {
        output.iter++;
        output.stagnant++;
        if (timeLimit - output.totalTime > 0.5 * timeLimit) {
            input.parameters["subTimeLimit"] = 0.5 * (timeLimit - output.totalTime);
        }
        else {
            input.parameters["subTimeLimit"] = 1.0 * (timeLimit - output.totalTime) + 0.01;
        }
        input.parameters["step"] = 2.0;
        int oldObj = tempSol.obj;
        int oldFea = tempSol.feaNum;
        SubInstance sIns(ins, fModel.isFixed);
        Solution sSol(sIns, input.parameters["gammaBase"], input.parameters["gamma"]);
        Frequency subFModel(sIns);
        ILP subsolver(sIns);
        input.k = subsolver.k;
        sSol.initialize_random(sIns);
        subFModel.initial();
        Output secondOutput(-1);
        firstSearch_new(sIns, sSol, subFModel, input, secondOutput);
        tempSol.restoreSol(sSol, ins, sIns);
        if (tempSol.feaNum == 0) {
            if (tempSol.obj > sol.obj) {
                sol.beCovered(tempSol);
                output.stagnant = 0;
                clock_t end = clock();
                output.findBestTime = (double)(end - output.beginTime) / CLOCKS_PER_SEC;
            }
        }
        input.parameters["fixRate"] = input.parameters["coreAvg"] * (0.5 + f.update(oldObj, oldFea, tempSol.obj, tempSol.feaNum));
        fModel.restoreFreq(subFModel, sIns);
        fModel.getFreqScore();
        subsolver.calculate(sSol);
        solver.restoreILP(subsolver, sIns);
        fModel.updateFixed(sol.select, solver.scoreX, ins.fixedFreq, ins.fixedIter, input.parameters["fixRate"], input.parameters["weight"]);
        output.getSubInfo(secondOutput);
        clock_t end = clock();
        output.totalTime = (double)(end - output.beginTime) / CLOCKS_PER_SEC;
        string tempStr = Output_fun::get_iter_info(input.parameters["if_print_iter_info"], output.iter, output.stagnant, secondOutput.iter, secondOutput.totalTime, output.totalTime, sIns.itemNum, sSol.obj, tempSol.obj, tempSol.feaNum, tempSol.k, sol.obj);
        output.iter_info += tempStr;
    }
    ins.printInformation(output);
    output.printOutput();
    sol.printInformation(output);
    output.output_info += Output::formato("The fixedNum") + to_string(fModel.fixNum) + "\n";
    input.parameters["delta"] = input.parameters["KownBest"] - sol.obj;
    output.out_parameters(input.parameters);
    output.out_parameters(output.times);
    sol.check(ins, output);
    f.getResult();
    string Qinfo = f.output();
    output.output_info += Qinfo;
    string outputPath = "../out/" + ins.insName + "_" + to_string(input.seed) + ".txt";
    if (sol.feaNum == 0) {
        sol.save_solution(ins, output);
    }
    string info = output.output(outputPath);
    return info;
}
