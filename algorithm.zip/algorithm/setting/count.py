import os 

def count(path:str):
    files = os.listdir(path)
    info  = dict()
    inss = []
    exprs = []
    for line in files:
        line = line.split("_")
        if len(line) != 4:continue
        ins = line[0]
        expr = line[1]
        if ins not in inss:
            inss.append(ins)
        if expr not in exprs:
            exprs.append(expr)
        if (ins,expr) in info.keys():
            info[ins,expr] += 1
        else:
            info[ins,expr] = 1
    print("---------------------",end="")
    for expr in exprs:
        print(" {:4s}  ".format(expr),end="")
    for line in inss:
        print("\n{:20s} : ".format(line),end="")
        for expr in exprs:
            if (line,expr) in info.keys():
                print(" {:4d}  ".format(info[line,expr]),end="")
            else:
                print(" {:4d}  ".format(0),end="")
    print()
count("./out/")
		
