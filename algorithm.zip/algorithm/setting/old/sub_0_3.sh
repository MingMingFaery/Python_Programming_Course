#!/bin/bash
#SBATCH -N 1
#SBATCH --mem-per-cpu=1000
#SBATCH --time=1000
#SBATCH --array=0-1
#SBATCH -o output/%A-%a.out
#SBATCH -e error/%A-%a.err
#SBATCH --mail-type=end,fail
#SBATCH --partition=intel-E5-2695
    

case $SLURM_ARRAY_TASK_ID in

    0)ARGS="./sins/9-1000-60-60-1.0-0.25-M.txt 3";;

esac


srun main_exe $ARGS

