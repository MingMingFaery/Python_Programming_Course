#!/bin/bash
#SBATCH -N 1
#SBATCH --mem-per-cpu=500
#SBATCH --time=1000
#SBATCH --array=0-39
#SBATCH -o output/%A-%a.out
#SBATCH -e error/%A-%a.err
#SBATCH --mail-type=end,fail
#SBATCH --partition=intel-E5-2670
    

case $SLURM_ARRAY_TASK_ID in

    0)ARGS="./sins/4-1000-60-60-1.0-0.5-P.txt 4";; 
    1)ARGS="./sins/500-30-30-0-2-1.txt 4";; 
    2)ARGS="./sins/500-30-30-0-2-14.txt 4";; 
    3)ARGS="./sins/500-30-30-0-2-6.txt 4";; 
    4)ARGS="./sins/500-30-30-1-5-10.txt 4";; 
    5)ARGS="./sins/500-30-30-1-5-15.txt 4";; 
    6)ARGS="./sins/500-30-30-1-5-5.txt 4";; 
    7)ARGS="./sins/7-1000-60-60-1.0-0.5-M.txt 4";; 
    8)ARGS="./sins/7-1000-60-60-1.0-0.75-M.txt 4";; 
    9)ARGS="./sins/7-1000-60-60-1.0-0.75-P.txt 4";; 
    10)ARGS="./sins/100-30-30-0-2-10.txt 5";; 
    11)ARGS="./sins/100-30-30-0-2-13.txt 5";; 
    12)ARGS="./sins/100-30-30-0-2-6.txt 5";; 
    13)ARGS="./sins/100-30-30-1-5-12.txt 5";; 
    14)ARGS="./sins/100-30-30-1-5-2.txt 5";; 
    15)ARGS="./sins/100-30-30-1-5-8.txt 5";; 
    16)ARGS="./sins/250-10-10-1-0.txt 5";; 
    17)ARGS="./sins/250-10-5-0-4.txt 5";; 
    18)ARGS="./sins/250-10-5-1-3.txt 5";; 
    19)ARGS="./sins/250-5-2-1-0.txt 5";; 
    20)ARGS="./sins/250-5-5-0-1.txt 5";; 
    21)ARGS="./sins/250-5-5-0-4.txt 5";; 
    22)ARGS="./sins/250-5-5-1-4.txt 5";; 
    23)ARGS="./sins/3-1000-60-60-1.0-0.25-P.txt 5";; 
    24)ARGS="./sins/4-1000-60-60-1.0-0.25-M.txt 5";; 
    25)ARGS="./sins/4-1000-60-60-1.0-0.5-P.txt 5";; 
    26)ARGS="./sins/500-30-30-0-2-1.txt 5";; 
    27)ARGS="./sins/500-30-30-0-2-14.txt 5";; 
    28)ARGS="./sins/500-30-30-0-2-6.txt 5";; 
    29)ARGS="./sins/500-30-30-1-5-10.txt 5";; 
    30)ARGS="./sins/500-30-30-1-5-15.txt 5";; 
    31)ARGS="./sins/500-30-30-1-5-5.txt 5";; 
    32)ARGS="./sins/7-1000-60-60-1.0-0.5-M.txt 5";; 
    33)ARGS="./sins/7-1000-60-60-1.0-0.75-M.txt 5";; 
    34)ARGS="./sins/7-1000-60-60-1.0-0.75-P.txt 5";; 
    35)ARGS="./sins/100-30-30-0-2-10.txt 6";; 
    36)ARGS="./sins/100-30-30-0-2-13.txt 6";; 
    37)ARGS="./sins/100-30-30-0-2-6.txt 6";; 
    38)ARGS="./sins/100-30-30-1-5-12.txt 6";; 
    39)ARGS="./sins/100-30-30-1-5-2.txt 6";; 

esac


srun main_exe $ARGS

 