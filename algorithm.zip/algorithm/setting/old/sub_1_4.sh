#!/bin/bash
#SBATCH -N 1
#SBATCH --mem-per-cpu=500
#SBATCH --time=1000
#SBATCH --array=0-39
#SBATCH -o output/%A-%a.out
#SBATCH -e error/%A-%a.err
#SBATCH --mail-type=end,fail
#SBATCH --partition=intel-E5-2670
    

case $SLURM_ARRAY_TASK_ID in

    0)ARGS="./sins/100-30-30-1-5-8.txt 6";; 
    1)ARGS="./sins/250-10-10-1-0.txt 6";; 
    2)ARGS="./sins/250-10-5-0-4.txt 6";; 
    3)ARGS="./sins/250-10-5-1-3.txt 6";; 
    4)ARGS="./sins/250-5-2-1-0.txt 6";; 
    5)ARGS="./sins/250-5-5-0-1.txt 6";; 
    6)ARGS="./sins/250-5-5-0-4.txt 6";; 
    7)ARGS="./sins/250-5-5-1-4.txt 6";; 
    8)ARGS="./sins/3-1000-60-60-1.0-0.25-P.txt 6";; 
    9)ARGS="./sins/4-1000-60-60-1.0-0.25-M.txt 6";; 
    10)ARGS="./sins/4-1000-60-60-1.0-0.5-P.txt 6";; 
    11)ARGS="./sins/500-30-30-0-2-1.txt 6";; 
    12)ARGS="./sins/500-30-30-0-2-14.txt 6";; 
    13)ARGS="./sins/500-30-30-0-2-6.txt 6";; 
    14)ARGS="./sins/500-30-30-1-5-10.txt 6";; 
    15)ARGS="./sins/500-30-30-1-5-15.txt 6";; 
    16)ARGS="./sins/500-30-30-1-5-5.txt 6";; 
    17)ARGS="./sins/7-1000-60-60-1.0-0.5-M.txt 6";; 
    18)ARGS="./sins/7-1000-60-60-1.0-0.75-M.txt 6";; 
    19)ARGS="./sins/7-1000-60-60-1.0-0.75-P.txt 6";; 
    20)ARGS="./sins/100-30-30-0-2-10.txt 7";; 
    21)ARGS="./sins/100-30-30-0-2-13.txt 7";; 
    22)ARGS="./sins/100-30-30-0-2-6.txt 7";; 
    23)ARGS="./sins/100-30-30-1-5-12.txt 7";; 
    24)ARGS="./sins/100-30-30-1-5-2.txt 7";; 
    25)ARGS="./sins/100-30-30-1-5-8.txt 7";; 
    26)ARGS="./sins/250-10-10-1-0.txt 7";; 
    27)ARGS="./sins/250-10-5-0-4.txt 7";; 
    28)ARGS="./sins/250-10-5-1-3.txt 7";; 
    29)ARGS="./sins/250-5-2-1-0.txt 7";; 
    30)ARGS="./sins/250-5-5-0-1.txt 7";; 
    31)ARGS="./sins/250-5-5-0-4.txt 7";; 
    32)ARGS="./sins/250-5-5-1-4.txt 7";; 
    33)ARGS="./sins/3-1000-60-60-1.0-0.25-P.txt 7";; 
    34)ARGS="./sins/4-1000-60-60-1.0-0.25-M.txt 7";; 
    35)ARGS="./sins/4-1000-60-60-1.0-0.5-P.txt 7";; 
    36)ARGS="./sins/500-30-30-0-2-1.txt 7";; 
    37)ARGS="./sins/500-30-30-0-2-14.txt 7";; 
    38)ARGS="./sins/500-30-30-0-2-6.txt 7";; 
    39)ARGS="./sins/500-30-30-1-5-10.txt 7";; 

esac


srun main_exe $ARGS

 