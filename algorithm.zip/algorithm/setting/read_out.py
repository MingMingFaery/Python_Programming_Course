import os 
# import pandas as pd 

def read(path:str):
    inss = os.listdir(path) 
    info = []
    for ins in inss:
        temp = dict()
        with open (path+ins) as f:
            lines = f.readlines()
            for line in lines:
                if "Q-learning" in line:continue
                line = line.strip('\n').strip()
                xx = line.split(":")
                if ":" in line:
                    attr = xx[0].strip()
                    if "The" in attr or "Thi" in attr or "Thc" in attr:
                        attr = attr.split(" ")[-1]
                    if len(xx)==2:
                        temp[attr] = xx[1].strip('\n').strip().replace(" ","-")
                    else:
                        temp[attr] = line.split(attr)[-1].strip().strip(":").strip()
                elif len(line) !=0 and '---' not in line:
                    line = line.split(" ")
                    if len(line) == 3:
                        temp['sol'] = line[-1]
                if '---' in line:
                    info.append(temp) 
                    temp = dict()
    # out = pd.DataFrame(columns=list(info[0].keys()))
    out = "index_0 "
    attrs = list(info[0].keys())
    for col in attrs:
        out += col 
        out += " "
    out = out.strip()
    out += "\n"
    for index in range(len(info)):
        #try:
            out += str(index) + " "
            for attr in attrs:
                try:
                    out += str(info[index][attr])
                    out += " "
                except:
                    print(attr,info[index])
            out += "\n"
        #except:
            #print(info[index])

    # out[out.columns[2:-2]] = out[out.columns[2:-2]].astype(float) 
    print("has read {:5d} lines data".format(len(info)))
    return out 

data = read("./out/")
with open("./res.txt","w") as f:
    f.write(data)
