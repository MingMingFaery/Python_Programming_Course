#!/bin/bash
#SBATCH -N 1
#SBATCH --mem-per-cpu=500
#SBATCH --time=1000
#SBATCH --array=0-29
#SBATCH -o output/%A-%a.out
#SBATCH -e error/%A-%a.err
#SBATCH --mail-type=end,fail
#SBATCH --partition=intel-E5-2670
    

case $SLURM_ARRAY_TASK_ID in

    0)ARGS="./sins/100-30-30-0-2-10.txt 1";; 
    1)ARGS="./sins/100-30-30-0-2-13.txt 1";; 
    2)ARGS="./sins/100-30-30-0-2-6.txt 1";; 
    3)ARGS="./sins/100-30-30-1-5-12.txt 1";; 
    4)ARGS="./sins/100-30-30-1-5-2.txt 1";; 
    5)ARGS="./sins/100-30-30-1-5-8.txt 1";; 
    6)ARGS="./sins/250-10-10-1-0.txt 1";; 
    7)ARGS="./sins/250-10-5-0-4.txt 1";; 
    8)ARGS="./sins/250-10-5-1-3.txt 1";; 
    9)ARGS="./sins/250-5-2-1-0.txt 1";; 
    10)ARGS="./sins/250-5-5-0-1.txt 1";; 
    11)ARGS="./sins/250-5-5-0-4.txt 1";; 
    12)ARGS="./sins/250-5-5-1-4.txt 1";; 
    13)ARGS="./sins/3-1000-60-60-1.0-0.25-P.txt 1";; 
    14)ARGS="./sins/4-1000-60-60-1.0-0.25-M.txt 1";; 
    15)ARGS="./sins/4-1000-60-60-1.0-0.5-P.txt 1";; 
    16)ARGS="./sins/500-30-30-0-2-1.txt 1";; 
    17)ARGS="./sins/500-30-30-0-2-14.txt 1";; 
    18)ARGS="./sins/500-30-30-0-2-6.txt 1";; 
    19)ARGS="./sins/500-30-30-1-5-10.txt 1";; 
    20)ARGS="./sins/500-30-30-1-5-15.txt 1";; 
    21)ARGS="./sins/500-30-30-1-5-5.txt 1";; 
    22)ARGS="./sins/7-1000-60-60-1.0-0.5-M.txt 1";; 
    23)ARGS="./sins/7-1000-60-60-1.0-0.75-M.txt 1";; 
    24)ARGS="./sins/7-1000-60-60-1.0-0.75-P.txt 1";; 
    25)ARGS="./sins/100-30-30-0-2-10.txt 2";; 
    26)ARGS="./sins/100-30-30-0-2-13.txt 2";; 
    27)ARGS="./sins/100-30-30-0-2-6.txt 2";; 
    28)ARGS="./sins/100-30-30-1-5-12.txt 2";; 
    29)ARGS="./sins/100-30-30-1-5-2.txt 2";; 

esac


srun main_exe $ARGS

 