#!/bin/bash
#SBATCH -N 1
#SBATCH --mem-per-cpu=500
#SBATCH --time=1000
#SBATCH --array=0-29
#SBATCH -o output/%A-%a.out
#SBATCH -e error/%A-%a.err
#SBATCH --mail-type=end,fail
#SBATCH --partition=intel-E5-2670
    

case $SLURM_ARRAY_TASK_ID in

    0)ARGS="./sins/250-5-5-0-1.txt 3";; 
    1)ARGS="./sins/250-5-5-0-4.txt 3";; 
    2)ARGS="./sins/250-5-5-1-4.txt 3";; 
    3)ARGS="./sins/3-1000-60-60-1.0-0.25-P.txt 3";; 
    4)ARGS="./sins/4-1000-60-60-1.0-0.25-M.txt 3";; 
    5)ARGS="./sins/4-1000-60-60-1.0-0.5-P.txt 3";; 
    6)ARGS="./sins/500-30-30-0-2-1.txt 3";; 
    7)ARGS="./sins/500-30-30-0-2-14.txt 3";; 
    8)ARGS="./sins/500-30-30-0-2-6.txt 3";; 
    9)ARGS="./sins/500-30-30-1-5-10.txt 3";; 
    10)ARGS="./sins/500-30-30-1-5-15.txt 3";; 
    11)ARGS="./sins/500-30-30-1-5-5.txt 3";; 
    12)ARGS="./sins/7-1000-60-60-1.0-0.5-M.txt 3";; 
    13)ARGS="./sins/7-1000-60-60-1.0-0.75-M.txt 3";; 
    14)ARGS="./sins/7-1000-60-60-1.0-0.75-P.txt 3";; 
    15)ARGS="./sins/100-30-30-0-2-10.txt 4";; 
    16)ARGS="./sins/100-30-30-0-2-13.txt 4";; 
    17)ARGS="./sins/100-30-30-0-2-6.txt 4";; 
    18)ARGS="./sins/100-30-30-1-5-12.txt 4";; 
    19)ARGS="./sins/100-30-30-1-5-2.txt 4";; 
    20)ARGS="./sins/100-30-30-1-5-8.txt 4";; 
    21)ARGS="./sins/250-10-10-1-0.txt 4";; 
    22)ARGS="./sins/250-10-5-0-4.txt 4";; 
    23)ARGS="./sins/250-10-5-1-3.txt 4";; 
    24)ARGS="./sins/250-5-2-1-0.txt 4";; 
    25)ARGS="./sins/250-5-5-0-1.txt 4";; 
    26)ARGS="./sins/250-5-5-0-4.txt 4";; 
    27)ARGS="./sins/250-5-5-1-4.txt 4";; 
    28)ARGS="./sins/3-1000-60-60-1.0-0.25-P.txt 4";; 
    29)ARGS="./sins/4-1000-60-60-1.0-0.25-M.txt 4";; 

esac


srun main_exe $ARGS

 