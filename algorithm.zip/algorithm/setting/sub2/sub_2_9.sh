#!/bin/bash
#SBATCH -N 1
#SBATCH --mem-per-cpu=500
#SBATCH --time=1000
#SBATCH --array=0-9
#SBATCH -o output/%A-%a.out
#SBATCH -e error/%A-%a.err
#SBATCH --mail-type=end,fail
#SBATCH --partition=intel-E5-2670
    

case $SLURM_ARRAY_TASK_ID in

    0)ARGS="./sins/4-1000-60-60-1.0-0.5-P.txt 10";; 
    1)ARGS="./sins/500-30-30-0-2-1.txt 10";; 
    2)ARGS="./sins/500-30-30-0-2-14.txt 10";; 
    3)ARGS="./sins/500-30-30-0-2-6.txt 10";; 
    4)ARGS="./sins/500-30-30-1-5-10.txt 10";; 
    5)ARGS="./sins/500-30-30-1-5-15.txt 10";; 
    6)ARGS="./sins/500-30-30-1-5-5.txt 10";; 
    7)ARGS="./sins/7-1000-60-60-1.0-0.5-M.txt 10";; 
    8)ARGS="./sins/7-1000-60-60-1.0-0.75-M.txt 10";; 
    9)ARGS="./sins/7-1000-60-60-1.0-0.75-P.txt 10";; 

esac


srun main_exe $ARGS

 