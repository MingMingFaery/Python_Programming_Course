#!/bin/bash
#SBATCH -N 1
#SBATCH --mem-per-cpu=500
#SBATCH --time=1000
#SBATCH --array=0-41
#SBATCH -o output/%A-%a.out
#SBATCH -e error/%A-%a.err
#SBATCH --mail-type=end,fail
#SBATCH --partition=intel-E5-2670
    

case $SLURM_ARRAY_TASK_ID in

    0)ARGS="./sins/500-30-30-0-2-6.txt 7";; 
    1)ARGS="./sins/500-30-30-1-5-10.txt 7";; 
    2)ARGS="./sins/500-30-30-1-5-15.txt 7";; 
    3)ARGS="./sins/500-30-30-1-5-5.txt 7";; 
    4)ARGS="./sins/7-1000-60-60-1.0-0.5-M.txt 7";; 
    5)ARGS="./sins/7-1000-60-60-1.0-0.75-M.txt 7";; 
    6)ARGS="./sins/7-1000-60-60-1.0-0.75-P.txt 7";; 
    7)ARGS="./sins/100-30-30-0-2-10.txt 8";; 
    8)ARGS="./sins/100-30-30-0-2-13.txt 8";; 
    9)ARGS="./sins/100-30-30-0-2-6.txt 8";; 
    10)ARGS="./sins/100-30-30-1-5-12.txt 8";; 
    11)ARGS="./sins/100-30-30-1-5-2.txt 8";; 
    12)ARGS="./sins/100-30-30-1-5-8.txt 8";; 
    13)ARGS="./sins/250-10-10-1-0.txt 8";; 
    14)ARGS="./sins/250-10-5-0-4.txt 8";; 
    15)ARGS="./sins/250-10-5-1-3.txt 8";; 
    16)ARGS="./sins/250-5-2-1-0.txt 8";; 
    17)ARGS="./sins/250-5-5-0-1.txt 8";; 
    18)ARGS="./sins/250-5-5-0-4.txt 8";; 
    19)ARGS="./sins/250-5-5-1-4.txt 8";; 
    20)ARGS="./sins/3-1000-60-60-1.0-0.25-P.txt 8";; 
    21)ARGS="./sins/4-1000-60-60-1.0-0.25-M.txt 8";; 
    22)ARGS="./sins/4-1000-60-60-1.0-0.5-P.txt 8";; 
    23)ARGS="./sins/500-30-30-0-2-1.txt 8";; 
    24)ARGS="./sins/500-30-30-0-2-14.txt 8";; 
    25)ARGS="./sins/500-30-30-0-2-6.txt 8";; 
    26)ARGS="./sins/500-30-30-1-5-10.txt 8";; 
    27)ARGS="./sins/500-30-30-1-5-15.txt 8";; 
    28)ARGS="./sins/500-30-30-1-5-5.txt 8";; 
    29)ARGS="./sins/7-1000-60-60-1.0-0.5-M.txt 8";; 
    30)ARGS="./sins/7-1000-60-60-1.0-0.75-M.txt 8";; 
    31)ARGS="./sins/7-1000-60-60-1.0-0.75-P.txt 8";; 
    32)ARGS="./sins/100-30-30-0-2-10.txt 9";; 
    33)ARGS="./sins/100-30-30-0-2-13.txt 9";; 
    34)ARGS="./sins/100-30-30-0-2-6.txt 9";; 
    35)ARGS="./sins/100-30-30-1-5-12.txt 9";; 
    36)ARGS="./sins/100-30-30-1-5-2.txt 9";; 
    37)ARGS="./sins/100-30-30-1-5-8.txt 9";; 
    38)ARGS="./sins/250-10-10-1-0.txt 9";; 
    39)ARGS="./sins/250-10-5-0-4.txt 9";; 
    40)ARGS="./sins/250-10-5-1-3.txt 9";; 
    41)ARGS="./sins/250-5-2-1-0.txt 9";; 

esac


srun main_exe $ARGS

 