#!/bin/bash
#SBATCH -N 1
#SBATCH --mem-per-cpu=500
#SBATCH --time=1000
#SBATCH --array=0-19
#SBATCH -o output/%A-%a.out
#SBATCH -e error/%A-%a.err
#SBATCH --mail-type=end,fail
#SBATCH --partition=intel-E5-2670
    

case $SLURM_ARRAY_TASK_ID in

    0)ARGS="./sins/3-1000-60-60-1.0-0.25-P.txt 1";; 
    1)ARGS="./sins/4-1000-60-60-1.0-0.25-M.txt 1";; 
    2)ARGS="./sins/4-1000-60-60-1.0-0.5-P.txt 1";; 
    3)ARGS="./sins/7-1000-60-60-1.0-0.5-M.txt 1";; 
    4)ARGS="./sins/7-1000-60-60-1.0-0.75-M.txt 1";; 
    5)ARGS="./sins/7-1000-60-60-1.0-0.75-P.txt 1";; 
    6)ARGS="./sins/3-1000-60-60-1.0-0.25-P.txt 2";; 
    7)ARGS="./sins/4-1000-60-60-1.0-0.25-M.txt 2";; 
    8)ARGS="./sins/4-1000-60-60-1.0-0.5-P.txt 2";; 
    9)ARGS="./sins/7-1000-60-60-1.0-0.5-M.txt 2";; 
    10)ARGS="./sins/7-1000-60-60-1.0-0.75-M.txt 2";; 
    11)ARGS="./sins/7-1000-60-60-1.0-0.75-P.txt 2";; 
    12)ARGS="./sins/3-1000-60-60-1.0-0.25-P.txt 3";; 
    13)ARGS="./sins/4-1000-60-60-1.0-0.25-M.txt 3";; 
    14)ARGS="./sins/4-1000-60-60-1.0-0.5-P.txt 3";; 
    15)ARGS="./sins/7-1000-60-60-1.0-0.5-M.txt 3";; 
    16)ARGS="./sins/7-1000-60-60-1.0-0.75-M.txt 3";; 
    17)ARGS="./sins/7-1000-60-60-1.0-0.75-P.txt 3";; 
    18)ARGS="./sins/3-1000-60-60-1.0-0.25-P.txt 4";; 
    19)ARGS="./sins/4-1000-60-60-1.0-0.25-M.txt 4";; 

esac


srun main_exe $ARGS

 