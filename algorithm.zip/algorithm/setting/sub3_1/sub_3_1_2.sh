#!/bin/bash
#SBATCH -N 1
#SBATCH --mem-per-cpu=500
#SBATCH --time=1000
#SBATCH --array=0-19
#SBATCH -o output/%A-%a.out
#SBATCH -e error/%A-%a.err
#SBATCH --mail-type=end,fail
#SBATCH --partition=intel-E5-2670
    

case $SLURM_ARRAY_TASK_ID in

    0)ARGS="./sins/4-1000-60-60-1.0-0.5-P.txt 4";; 
    1)ARGS="./sins/7-1000-60-60-1.0-0.5-M.txt 4";; 
    2)ARGS="./sins/7-1000-60-60-1.0-0.75-M.txt 4";; 
    3)ARGS="./sins/7-1000-60-60-1.0-0.75-P.txt 4";; 
    4)ARGS="./sins/3-1000-60-60-1.0-0.25-P.txt 5";; 
    5)ARGS="./sins/4-1000-60-60-1.0-0.25-M.txt 5";; 
    6)ARGS="./sins/4-1000-60-60-1.0-0.5-P.txt 5";; 
    7)ARGS="./sins/7-1000-60-60-1.0-0.5-M.txt 5";; 
    8)ARGS="./sins/7-1000-60-60-1.0-0.75-M.txt 5";; 
    9)ARGS="./sins/7-1000-60-60-1.0-0.75-P.txt 5";; 
    10)ARGS="./sins/3-1000-60-60-1.0-0.25-P.txt 6";; 
    11)ARGS="./sins/4-1000-60-60-1.0-0.25-M.txt 6";; 
    12)ARGS="./sins/4-1000-60-60-1.0-0.5-P.txt 6";; 
    13)ARGS="./sins/7-1000-60-60-1.0-0.5-M.txt 6";; 
    14)ARGS="./sins/7-1000-60-60-1.0-0.75-M.txt 6";; 
    15)ARGS="./sins/7-1000-60-60-1.0-0.75-P.txt 6";; 
    16)ARGS="./sins/3-1000-60-60-1.0-0.25-P.txt 7";; 
    17)ARGS="./sins/4-1000-60-60-1.0-0.25-M.txt 7";; 
    18)ARGS="./sins/4-1000-60-60-1.0-0.5-P.txt 7";; 
    19)ARGS="./sins/7-1000-60-60-1.0-0.5-M.txt 7";; 

esac


srun main_exe $ARGS

 