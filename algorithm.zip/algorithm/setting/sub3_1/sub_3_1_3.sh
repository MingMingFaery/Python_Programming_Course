#!/bin/bash
#SBATCH -N 1
#SBATCH --mem-per-cpu=500
#SBATCH --time=1000
#SBATCH --array=0-19
#SBATCH -o output/%A-%a.out
#SBATCH -e error/%A-%a.err
#SBATCH --mail-type=end,fail
#SBATCH --partition=intel-E5-2670
    

case $SLURM_ARRAY_TASK_ID in

    0)ARGS="./sins/7-1000-60-60-1.0-0.75-M.txt 7";; 
    1)ARGS="./sins/7-1000-60-60-1.0-0.75-P.txt 7";; 
    2)ARGS="./sins/3-1000-60-60-1.0-0.25-P.txt 8";; 
    3)ARGS="./sins/4-1000-60-60-1.0-0.25-M.txt 8";; 
    4)ARGS="./sins/4-1000-60-60-1.0-0.5-P.txt 8";; 
    5)ARGS="./sins/7-1000-60-60-1.0-0.5-M.txt 8";; 
    6)ARGS="./sins/7-1000-60-60-1.0-0.75-M.txt 8";; 
    7)ARGS="./sins/7-1000-60-60-1.0-0.75-P.txt 8";; 
    8)ARGS="./sins/3-1000-60-60-1.0-0.25-P.txt 9";; 
    9)ARGS="./sins/4-1000-60-60-1.0-0.25-M.txt 9";; 
    10)ARGS="./sins/4-1000-60-60-1.0-0.5-P.txt 9";; 
    11)ARGS="./sins/7-1000-60-60-1.0-0.5-M.txt 9";; 
    12)ARGS="./sins/7-1000-60-60-1.0-0.75-M.txt 9";; 
    13)ARGS="./sins/7-1000-60-60-1.0-0.75-P.txt 9";; 
    14)ARGS="./sins/3-1000-60-60-1.0-0.25-P.txt 10";; 
    15)ARGS="./sins/4-1000-60-60-1.0-0.25-M.txt 10";; 
    16)ARGS="./sins/4-1000-60-60-1.0-0.5-P.txt 10";; 
    17)ARGS="./sins/7-1000-60-60-1.0-0.5-M.txt 10";; 
    18)ARGS="./sins/7-1000-60-60-1.0-0.75-M.txt 10";; 
    19)ARGS="./sins/7-1000-60-60-1.0-0.75-P.txt 10";; 

esac


srun main_exe $ARGS

 