#!/bin/bash
#SBATCH -N 1
#SBATCH --mem-per-cpu=800
#SBATCH --time=1000
#SBATCH --array=0-14
#SBATCH -o output/%A-%a.out
#SBATCH -e error/%A-%a.err
#SBATCH --mail-type=end,fail
#SBATCH --partition=intel-E5-2670
    

case $SLURM_ARRAY_TASK_ID in

    0)ARGS="./sins/250-10-5-0-4.txt 3";; 
    1)ARGS="./sins/250-10-5-1-3.txt 3";; 
    2)ARGS="./sins/250-5-2-1-0.txt 3";; 
    3)ARGS="./sins/250-5-5-0-1.txt 3";; 
    4)ARGS="./sins/250-5-5-0-4.txt 3";; 
    5)ARGS="./sins/250-5-5-1-4.txt 3";; 
    6)ARGS="./sins/500-30-30-0-2-1.txt 3";; 
    7)ARGS="./sins/500-30-30-0-2-14.txt 3";; 
    8)ARGS="./sins/500-30-30-0-2-6.txt 3";; 
    9)ARGS="./sins/500-30-30-1-5-10.txt 3";; 
    10)ARGS="./sins/500-30-30-1-5-15.txt 3";; 
    11)ARGS="./sins/500-30-30-1-5-5.txt 3";; 
    12)ARGS="./sins/100-30-30-0-2-10.txt 4";; 
    13)ARGS="./sins/100-30-30-0-2-13.txt 4";; 
    14)ARGS="./sins/100-30-30-0-2-6.txt 4";; 

esac


srun main_exe $ARGS

 