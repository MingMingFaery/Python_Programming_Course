#!/bin/bash
#SBATCH -N 1
#SBATCH --mem-per-cpu=800
#SBATCH --time=1000
#SBATCH --array=0-4
#SBATCH -o output/%A-%a.out
#SBATCH -e error/%A-%a.err
#SBATCH --mail-type=end,fail
#SBATCH --partition=intel-E5-2670
    

case $SLURM_ARRAY_TASK_ID in

    0)ARGS="./sins/500-30-30-0-2-14.txt 5";; 
    1)ARGS="./sins/500-30-30-0-2-6.txt 5";; 
    2)ARGS="./sins/500-30-30-1-5-10.txt 5";; 
    3)ARGS="./sins/500-30-30-1-5-15.txt 5";; 
    4)ARGS="./sins/500-30-30-1-5-5.txt 5";; 

esac


srun main_exe $ARGS

 